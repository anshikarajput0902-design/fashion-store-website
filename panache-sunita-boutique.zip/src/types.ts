export type CategoryId =
  | 'bridal-wear'
  | 'party-wear'
  | 'ethnic-wear'
  | 'kurtis'
  | 'gowns'
  | 'sarees'
  | 'lehengas'
  | 'indo-western';

export interface Category {
  id: CategoryId;
  name: string;
  description: string;
  image: string;
  itemCount: number;
  highlightTag?: string;
}

export interface OutfitProduct {
  id: string;
  name: string;
  categoryId: CategoryId;
  categoryName: string;
  price: number;
  originalPrice?: number;
  fabric: string;
  workType: string; // e.g., Zardozi, Gota Patti, Mirror Work, Thread Embroidery
  colors: string[];
  image: string;
  additionalImages?: string[];
  rating: number;
  reviewsCount: number;
  inStock: boolean;
  isBestSeller?: boolean;
  isNewArrival?: boolean;
  description: string;
  sizes: string[];
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  source: string; // e.g. "Google Review"
  comment: string;
  outfitPurchased?: string;
  avatar?: string;
  verified: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Bridal' | 'Interior' | 'Custom Handwork' | 'Real Brides' | 'Party Wear';
  image: string;
  caption: string;
}

export interface CustomOutfitRequest {
  outfitType: string;
  fabricPreference: string;
  embroideryType: string;
  colorPreference: string;
  budgetRange: string;
  eventDate: string;
  clientName: string;
  phone: string;
  email: string;
  city: string;
  notes: string;
  measurementOption: 'self' | 'boutique-visit' | 'home-visit-raipur';
  measurements?: {
    bust?: string;
    waist?: string;
    hips?: string;
    blouseLength?: string;
    shoulderWidth?: string;
    lehengaLength?: string;
  };
}

export interface BoutiqueContactInfo {
  name: string;
  tagline: string;
  address: string;
  landmark: string;
  city: string;
  pincode: string;
  googleMapPlusCode: string;
  phone: string;
  whatsapp: string;
  email: string;
  rating: number;
  totalReviews: number;
  hours: {
    weekdays: string;
    sunday: string;
  };
}
