import React from 'react';
import { OutfitProduct } from '../types';
import { FEATURED_PRODUCTS, BOUTIQUE_INFO } from '../data/boutiqueData';
import { X, Heart, Trash2, MessageCircle, ArrowRight, Sparkles } from 'lucide-react';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistIds: string[];
  onRemoveFromWishlist: (productId: string) => void;
  onQuickView: (product: OutfitProduct) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistIds,
  onRemoveFromWishlist,
  onQuickView,
}) => {
  if (!isOpen) return null;

  const savedProducts = FEATURED_PRODUCTS.filter((p) => wishlistIds.includes(p.id));
  const totalPrice = savedProducts.reduce((sum, item) => sum + item.price, 0);

  const handleBatchWhatsappInquiry = () => {
    const itemsList = savedProducts
      .map((p, i) => `${i + 1}. ${p.name} (₹${p.price.toLocaleString('en-IN')})`)
      .join('\n');

    const text = encodeURIComponent(
      `Hi Panache Sunita Boutique! I would like to inquire about my saved outfits list:\n\n` +
      `${itemsList}\n\n` +
      `Total Estimated Price: ₹${totalPrice.toLocaleString('en-IN')}\n` +
      `Please share availability and stitching details!`
    );

    window.open(`https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex justify-end">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between border-l border-[#D4AF37]/30">
        
        {/* Drawer Header */}
        <div className="p-5 border-b border-stone-100 flex items-center justify-between bg-[#FAF8F5]">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center">
              <Heart className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h3 className="font-serif-luxury text-lg font-bold text-[#1A1613]">
                Saved Outfits
              </h3>
              <span className="text-xs text-stone-500">
                {savedProducts.length} {savedProducts.length === 1 ? 'item' : 'items'} in wishlist
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-stone-500 hover:text-black rounded-full hover:bg-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wishlist Items List */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          {savedProducts.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <Heart className="w-12 h-12 text-stone-300 mx-auto" />
              <h4 className="font-serif-luxury text-lg font-bold text-[#1A1613]">
                Your Wishlist is Empty
              </h4>
              <p className="text-xs text-stone-500 max-w-xs mx-auto">
                Explore our signature collection and click the heart icon to save your favorite bridal and party outfits.
              </p>
            </div>
          ) : (
            savedProducts.map((item) => (
              <div
                key={item.id}
                className="flex items-center space-x-3 p-3 rounded-2xl border border-stone-200 hover:border-[#D4AF37]/40 bg-white transition-all shadow-xs"
              >
                <img
                  src={item.image}
                  alt={item.name}
                  referrerPolicy="no-referrer"
                  className="w-20 h-24 object-cover rounded-xl cursor-pointer"
                  onClick={() => {
                    onClose();
                    onQuickView(item);
                  }}
                />

                <div className="flex-1 space-y-1">
                  <span className="text-[10px] text-[#9A7712] font-semibold uppercase tracking-wider block">
                    {item.categoryName}
                  </span>
                  <h4 
                    onClick={() => {
                      onClose();
                      onQuickView(item);
                    }}
                    className="font-serif-luxury text-xs font-bold text-[#1A1613] line-clamp-1 cursor-pointer hover:text-[#9A7712]"
                  >
                    {item.name}
                  </h4>
                  <span className="font-bold text-xs text-[#1A1613] block">
                    ₹{item.price.toLocaleString('en-IN')}
                  </span>
                  <span className="text-[10px] text-stone-500 block">
                    {item.fabric}
                  </span>
                </div>

                <button
                  onClick={() => onRemoveFromWishlist(item.id)}
                  className="p-2 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                  title="Remove"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Drawer Footer */}
        {savedProducts.length > 0 && (
          <div className="p-5 border-t border-stone-200 bg-[#FAF8F5] space-y-3">
            <div className="flex justify-between text-xs font-semibold text-[#1A1613]">
              <span>Total Estimated Price:</span>
              <span className="font-bold text-base text-[#9A7712]">
                ₹{totalPrice.toLocaleString('en-IN')}
              </span>
            </div>

            <button
              onClick={handleBatchWhatsappInquiry}
              className="w-full flex items-center justify-center space-x-2 bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs py-3.5 rounded-xl shadow-md transition-colors uppercase tracking-wider"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>Inquire All Saved Outfits on WhatsApp</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
