import React from 'react';
import { Sparkles, Scissors, Award, HeartHandshake, Clock } from 'lucide-react';
import { WHY_CHOOSE_US } from '../data/boutiqueData';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-[#DFBA67]" />;
      case 'Scissors':
        return <Scissors className="w-6 h-6 text-[#DFBA67]" />;
      case 'Award':
        return <Award className="w-6 h-6 text-[#DFBA67]" />;
      case 'HeartHandshake':
        return <HeartHandshake className="w-6 h-6 text-[#DFBA67]" />;
      case 'Clock':
        return <Clock className="w-6 h-6 text-[#DFBA67]" />;
      default:
        return <Sparkles className="w-6 h-6 text-[#DFBA67]" />;
    }
  };

  return (
    <section className="py-20 bg-[#FAF8F5] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#F4ECE1] px-3.5 py-1 rounded-full border border-[#D4AF37]/30">
            <Award className="w-3.5 h-3.5" />
            <span>The Panache Difference</span>
          </div>

          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1A1613]">
            Why Choose Panache Sunita Boutique
          </h2>

          <p className="text-sm text-[#6A5E54]">
            Every outfit is crafted with meticulous attention to detail, luxury raw materials, and dedicated personal care.
          </p>
        </div>

        {/* 5 Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {WHY_CHOOSE_US.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl p-6 border border-[#D4AF37]/20 shadow-xs hover:shadow-lg transition-all space-y-4 flex flex-col justify-between group"
            >
              <div className="w-12 h-12 rounded-2xl bg-[#1A1613] flex items-center justify-center group-hover:scale-110 transition-transform shadow-md">
                {getIcon(item.icon)}
              </div>

              <div className="space-y-1.5">
                <h3 className="font-serif-luxury text-base font-bold text-[#1A1613] group-hover:text-[#9A7712] transition-colors">
                  {item.title}
                </h3>
                <p className="text-xs text-[#6A5E54] leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-2 border-t border-stone-100 text-[10px] font-bold text-[#9A7712] uppercase tracking-wider">
                ✓ Guaranteed Excellence
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
