import React from 'react';
import { Sparkles, ArrowRight, Star, Scissors, MapPin, CheckCircle2 } from 'lucide-react';
import { BOUTIQUE_INFO } from '../data/boutiqueData';
import heroFashionModelImg from '../assets/images/hero_fashion_model_1785919742555.jpg';

interface HeroProps {
  onExploreCollections: () => void;
  onBookCustomFit: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreCollections, onBookCustomFit }) => {
  return (
    <section id="hero" className="relative pt-28 pb-16 lg:pt-36 lg:pb-24 bg-[#FAF8F5] overflow-hidden">
      {/* Background Decorative Accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#DFBA67]/10 rounded-full blur-3xl -z-0" />
      <div className="absolute bottom-10 left-0 w-80 h-80 bg-[#E5D7C4]/30 rounded-full blur-3xl -z-0" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Hero Text Column */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            {/* Tagline Pill */}
            <div className="inline-flex items-center space-x-2 bg-[#F4ECE1] border border-[#D4AF37]/30 rounded-full px-4 py-1.5 shadow-xs">
              <Sparkles className="w-4 h-4 text-[#9A7712]" />
              <span className="text-xs font-semibold uppercase tracking-wider text-[#9A7712]">
                Raipur's Premier Luxury Boutique
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif-luxury text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#1A1613] leading-[1.15]">
              Where <span className="text-gold-metallic italic font-normal">Elegance</span> Meets Style
            </h1>

            {/* Subtext */}
            <p className="text-base sm:text-lg text-[#5A5047] max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
              Step into the world of bespoke fashion at <strong className="text-[#1A1613] font-semibold">Panache Sunita Boutique</strong>. 
              From breathtaking royal bridal lehengas to customized party gowns, sarees, and kurtis — every creation is intricately handcrafted to complement your unique grace.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={onBookCustomFit}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 bg-gold-gradient text-white font-semibold text-sm px-8 py-4 rounded-full shadow-md hover:shadow-lg hover:brightness-105 transition-all uppercase tracking-wider group"
              >
                <span>Book Custom Fitting</span>
                <Scissors className="w-4 h-4 group-hover:rotate-12 transition-transform" />
              </button>

              <button
                onClick={onExploreCollections}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 bg-white text-[#1A1613] border border-[#D4AF37]/40 hover:bg-[#F4ECE1] text-sm font-semibold px-8 py-4 rounded-full transition-all uppercase tracking-wider group"
              >
                <span>Shop Collections</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform text-[#9A7712]" />
              </button>
            </div>

            {/* Trust Badges */}
            <div className="pt-6 border-t border-[#D4AF37]/20 grid grid-cols-3 gap-4 max-w-xl mx-auto lg:mx-0 text-center sm:text-left">
              <div>
                <div className="flex items-center justify-center sm:justify-start space-x-1 text-[#9A7712]">
                  <Star className="w-4 h-4 fill-current text-[#DFBA67]" />
                  <span className="font-bold text-lg text-[#1A1613]">{BOUTIQUE_INFO.rating} ★</span>
                </div>
                <p className="text-xs text-[#7A6E65] mt-0.5">151+ Google Reviews</p>
              </div>

              <div>
                <div className="flex items-center justify-center sm:justify-start space-x-1 text-[#9A7712]">
                  <CheckCircle2 className="w-4 h-4 text-[#9A7712]" />
                  <span className="font-bold text-lg text-[#1A1613]">100%</span>
                </div>
                <p className="text-xs text-[#7A6E65] mt-0.5">Custom Fit Guarantee</p>
              </div>

              <div>
                <div className="flex items-center justify-center sm:justify-start space-x-1 text-[#9A7712]">
                  <MapPin className="w-4 h-4 text-[#9A7712]" />
                  <span className="font-bold text-lg text-[#1A1613]">Civil Lines</span>
                </div>
                <p className="text-xs text-[#7A6E65] mt-0.5">Katora Talab, Raipur</p>
              </div>
            </div>

          </div>

          {/* Right Hero Visual Banner */}
          <div className="lg:col-span-5 relative">
            
            {/* Main Visual Image Frame */}
            <div className="relative mx-auto max-w-md lg:max-w-none rounded-3xl overflow-hidden shadow-2xl border-4 border-[#FAF8F5] group">
              <img
                src={heroFashionModelImg}
                alt="Panache Sunita Boutique Designer Outfit Model"
                referrerPolicy="no-referrer"
                className="w-full h-[480px] sm:h-[560px] object-cover object-top group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1A1613]/80 via-transparent to-transparent opacity-90" />
              
              {/* Bottom Overlay Label */}
              <div className="absolute bottom-6 left-6 right-6 text-white space-y-1">
                <span className="inline-block bg-[#D4AF37] text-[#1A1613] text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded">
                  Bespoke Couture
                </span>
                <h3 className="font-serif-luxury text-2xl font-bold text-white">
                  Royal Bridal Collection 2026
                </h3>
                <p className="text-xs text-amber-100/90 font-light">
                  Handcrafted with zardozi & gota patti by master weavers.
                </p>
              </div>
            </div>

            {/* Floating Review Card Overlay */}
            <div className="absolute -bottom-6 -left-6 hidden sm:flex items-center space-x-3 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-[#D4AF37]/30 max-w-xs">
              <div className="w-10 h-10 rounded-full bg-[#DFBA67]/20 flex items-center justify-center text-[#9A7712] font-bold font-serif-luxury text-lg">
                S
              </div>
              <div className="text-left text-xs">
                <div className="flex items-center space-x-1 text-amber-500 font-bold">
                  <span>★ ★ ★ ★ ★</span>
                </div>
                <p className="text-[#1A1613] font-medium line-clamp-2 mt-0.5">
                  "They understood exactly what I wanted and delivered it beautifully!"
                </p>
                <span className="text-[10px] text-gray-400 block mt-0.5">— Priya S., Verified Buyer</span>
              </div>
            </div>

            {/* Floating Tailoring Pill */}
            <div className="absolute -top-4 -right-4 hidden sm:flex items-center space-x-2 bg-[#1A1613] text-[#FAF8F5] px-4 py-2 rounded-full shadow-lg border border-[#D4AF37]/40 text-xs">
              <Scissors className="w-4 h-4 text-[#DFBA67]" />
              <span className="font-medium text-[#DFBA67]">Custom Fitting & Stitching</span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
