import React from 'react';
import { X, Scissors, Check, Info } from 'lucide-react';

interface MeasurementGuideModalProps {
  onClose: () => void;
  onOpenCustomDesign: () => void;
}

export const MeasurementGuideModal: React.FC<MeasurementGuideModalProps> = ({
  onClose,
  onOpenCustomDesign,
}) => {
  const steps = [
    {
      title: 'Bust / Chest Measurement',
      desc: 'Measure around the fullest part of your bust while wearing a comfortable bra. Keep the tape straight across your back.',
      tip: 'Do not pull the tape too tight — leave room for comfortable breathing.'
    },
    {
      title: 'Natural Waist',
      desc: 'Measure around your natural waistline (usually 1-2 inches above your navel or the narrowest part of your torso).',
      tip: 'Stand straight without holding your breath.'
    },
    {
      title: 'Hips',
      desc: 'Stand with your feet together and measure around the fullest part of your hips and rear.',
      tip: 'Crucial for fitted gowns, shararas, and fish-cut lehengas.'
    },
    {
      title: 'Blouse Length & Shoulder Width',
      desc: 'Measure from the top of your shoulder seam down to your desired blouse hem length (usually 14–16 inches). For shoulder width, measure from one shoulder tip seam to the other across your upper back.',
      tip: 'Tell us if you prefer deep necklines or padded cups.'
    },
    {
      title: 'Lehenga / Skirt Length',
      desc: 'Measure from where you wear your lehenga waist tie down to the floor, while wearing your wedding heels or shoes.',
      tip: 'Always wear the exact heels you plan to wear for your event!'
    }
  ];

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-3xl max-w-3xl w-full border border-[#D4AF37]/30 shadow-2xl overflow-hidden my-auto relative p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2.5 text-stone-500 hover:text-black hover:bg-stone-100 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#F4ECE1] px-3 py-0.5 rounded-full">
            <Scissors className="w-3.5 h-3.5" />
            <span>Fitting Guide</span>
          </div>
          <h2 className="font-serif-luxury text-2xl font-bold text-[#1A1613]">
            How to Take Custom Measurements
          </h2>
          <p className="text-xs text-[#6A5E54]">
            Follow these simple steps for taking your measurements at home, or visit our Raipur boutique for a professional fitting by master female tailors.
          </p>
        </div>

        {/* Raipur Boutique Special Box */}
        <div className="bg-[#1A1613] text-[#FAF8F5] p-4 rounded-2xl border border-[#D4AF37]/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="space-y-0.5">
            <span className="font-bold text-[#DFBA67] block">🏡 Reside in Raipur, Chhattisgarh?</span>
            <p className="text-stone-300">Request a female master tailor doorstep visit or pop into our Katora Talab boutique.</p>
          </div>
          <button
            onClick={() => {
              onClose();
              onOpenCustomDesign();
            }}
            className="bg-gold-gradient text-white font-bold px-4 py-2 rounded-xl text-[11px] whitespace-nowrap shadow-sm"
          >
            Request Doorstep Visit
          </button>
        </div>

        {/* Measurement Steps */}
        <div className="space-y-4">
          {steps.map((step, idx) => (
            <div key={idx} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-1.5">
              <div className="flex items-center space-x-2">
                <span className="w-6 h-6 rounded-full bg-[#9A7712] text-white font-bold text-xs flex items-center justify-center">
                  {idx + 1}
                </span>
                <h3 className="font-serif-luxury font-bold text-sm text-[#1A1613]">
                  {step.title}
                </h3>
              </div>
              <p className="text-xs text-[#5A5047] pl-8 leading-relaxed">
                {step.desc}
              </p>
              <div className="pl-8 flex items-center space-x-1 text-[11px] text-[#9A7712] italic">
                <Info className="w-3 h-3 flex-shrink-0" />
                <span>Tip: {step.tip}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer CTAs */}
        <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-stone-500">
            Have questions? Our stylists are available 11 AM – 9 PM on WhatsApp.
          </p>
          <button
            onClick={onClose}
            className="w-full sm:w-auto bg-[#1A1613] text-white text-xs font-semibold px-6 py-2.5 rounded-xl hover:bg-stone-800 transition-colors"
          >
            Got It, Thanks!
          </button>
        </div>

      </div>
    </div>
  );
};
