import React from 'react';
import { REVIEWS, BOUTIQUE_INFO } from '../data/boutiqueData';
import { Star, Sparkles, Quote, CheckCircle2, ThumbsUp } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section id="reviews" className="py-20 bg-[#F4ECE1]/40 border-y border-[#D4AF37]/20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#FAF8F5] px-3.5 py-1 rounded-full border border-[#D4AF37]/30 shadow-xs">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Verified Customer Feedback</span>
          </div>

          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1A1613]">
            What Our Clients Say
          </h2>

          <p className="text-sm text-[#6A5E54]">
            Consistently praised for beautiful, trendy, and elegant custom outfits, excellent fabric quality, neat finishing, and friendly staff.
          </p>

          {/* Google Review Rating Highlight Box */}
          <div className="inline-flex items-center space-x-4 bg-white px-6 py-3 rounded-2xl shadow-sm border border-[#D4AF37]/30 mt-2">
            <div className="flex items-center space-x-1 text-amber-500 font-bold text-xl">
              <span>{BOUTIQUE_INFO.rating}</span>
              <div className="flex text-amber-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
            </div>
            <span className="text-stone-300">|</span>
            <div className="text-left text-xs">
              <span className="font-bold text-[#1A1613] block">Google Review Rating</span>
              <span className="text-[#9A7712] font-semibold">{BOUTIQUE_INFO.totalReviews} Verified Customer Reviews</span>
            </div>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {REVIEWS.map((rev) => (
            <div
              key={rev.id}
              className="bg-white rounded-3xl p-6 sm:p-7 border border-[#D4AF37]/20 shadow-xs hover:shadow-lg transition-all flex flex-col justify-between space-y-4 relative"
            >
              <Quote className="w-8 h-8 text-[#DFBA67]/30 absolute top-6 right-6" />

              <div className="space-y-3">
                {/* Star Rating & Badge */}
                <div className="flex items-center justify-between">
                  <div className="flex text-amber-400">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <span className="text-[10px] bg-[#FAF8F5] text-[#9A7712] font-semibold px-2.5 py-1 rounded-full border border-[#D4AF37]/20">
                    {rev.source}
                  </span>
                </div>

                {/* Review Text */}
                <p className="text-xs sm:text-sm text-[#4A423A] leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              {/* Reviewer Details */}
              <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-gold-gradient text-white flex items-center justify-center font-serif-luxury font-bold text-base shadow-xs">
                    {rev.author.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-[#1A1613] flex items-center space-x-1">
                      <span>{rev.author}</span>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 inline" />
                    </h4>
                    {rev.outfitPurchased && (
                      <span className="text-[10px] text-[#9A7712] font-medium block">
                        {rev.outfitPurchased}
                      </span>
                    )}
                  </div>
                </div>

                <span className="text-[10px] text-stone-400 font-medium">
                  {rev.date}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
