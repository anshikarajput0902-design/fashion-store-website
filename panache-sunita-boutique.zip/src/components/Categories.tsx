import React from 'react';
import { CATEGORIES } from '../data/boutiqueData';
import { CategoryId } from '../types';
import { ArrowUpRight, Sparkles } from 'lucide-react';

interface CategoriesProps {
  onSelectCategory: (categoryId: CategoryId) => void;
}

export const Categories: React.FC<CategoriesProps> = ({ onSelectCategory }) => {
  return (
    <section id="categories" className="py-20 bg-[#F4ECE1]/50 border-y border-[#D4AF37]/15 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#FAF8F5] px-3.5 py-1 rounded-full border border-[#D4AF37]/30 shadow-xs">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Curated Collections</span>
          </div>

          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1A1613]">
            Explore Designer Categories
          </h2>

          <p className="text-sm sm:text-base text-[#6A5E54]">
            From timeless handloom sarees and royal bridal lehengas to modern Indo-Western gowns, discover custom couture tailored exclusively for every occasion.
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {CATEGORIES.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-[#D4AF37]/20 transition-all duration-300 cursor-pointer flex flex-col justify-between"
            >
              {/* Image Thumbnail Header */}
              <div className="relative h-64 w-full overflow-hidden bg-stone-100">
                <img
                  src={cat.image}
                  alt={cat.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1613]/70 via-[#1A1613]/20 to-transparent" />
                
                {/* Category Count Tag */}
                <span className="absolute top-3 right-3 bg-[#1A1613]/80 backdrop-blur-md text-[#DFBA67] text-[10px] font-bold px-3 py-1 rounded-full border border-[#D4AF37]/30">
                  {cat.itemCount}+ Designs
                </span>

                {cat.highlightTag && (
                  <span className="absolute top-3 left-3 bg-gold-gradient text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded">
                    {cat.highlightTag}
                  </span>
                )}

                {/* Quick Arrow Icon */}
                <div className="absolute bottom-4 right-4 w-9 h-9 rounded-full bg-white/90 text-[#1A1613] flex items-center justify-center group-hover:bg-[#D4AF37] group-hover:text-white transition-all shadow-md">
                  <ArrowUpRight className="w-5 h-5 group-hover:rotate-45 transition-transform" />
                </div>

                <div className="absolute bottom-4 left-4 right-14 text-white">
                  <h3 className="font-serif-luxury text-xl font-bold leading-tight drop-shadow-sm">
                    {cat.name}
                  </h3>
                </div>
              </div>

              {/* Card Footer */}
              <div className="p-5 space-y-2 flex-1 flex flex-col justify-between bg-white">
                <p className="text-xs text-[#6A5E54] line-clamp-2 leading-relaxed">
                  {cat.description}
                </p>
                <div className="pt-2 flex items-center justify-between text-xs font-semibold text-[#9A7712] group-hover:text-[#1A1613] transition-colors">
                  <span>Explore Designs</span>
                  <span className="text-[10px] uppercase tracking-wider font-bold">Custom Fit Available →</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
