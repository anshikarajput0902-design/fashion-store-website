import React from 'react';
import { Sparkles, Award, Heart, Check, Users, Scissors } from 'lucide-react';
import { BOUTIQUE_INFO } from '../data/boutiqueData';
import boutiqueInteriorImg from '../assets/images/boutique_interior_1785919755789.jpg';
import customHandworkImg from '../assets/images/custom_handwork_1785919768516.jpg';

export const AboutUs: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-[#F4ECE1]/40 border-y border-[#D4AF37]/20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Grid Images */}
          <div className="lg:col-span-6 grid grid-cols-2 gap-4 relative">
            <div className="space-y-4">
              <div className="rounded-3xl overflow-hidden shadow-lg border-2 border-white h-64 sm:h-72">
                <img
                  src={boutiqueInteriorImg}
                  alt="Panache Sunita Boutique Interior"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="bg-[#1A1613] text-[#FAF8F5] p-5 rounded-2xl border border-[#D4AF37]/30 shadow-md">
                <span className="font-serif-luxury text-3xl font-bold text-gold-metallic block">
                  10+ Years
                </span>
                <p className="text-xs text-[#E5D7C4] mt-1 font-medium">
                  Designing royal bridal wear and bespoke ethnic couture in Raipur.
                </p>
              </div>
            </div>

            <div className="space-y-4 pt-8">
              <div className="bg-gold-gradient text-white p-5 rounded-2xl shadow-md space-y-1">
                <span className="font-serif-luxury text-3xl font-bold block">
                  5,000+
                </span>
                <p className="text-xs text-amber-100 font-medium">
                  Custom outfits handcrafted with perfect fitting guarantee.
                </p>
              </div>
              <div className="rounded-3xl overflow-hidden shadow-lg border-2 border-white h-64 sm:h-72">
                <img
                  src={customHandworkImg}
                  alt="Intricate Zardozi Handwork"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                />
              </div>
            </div>
          </div>

          {/* Right Brand Story Text */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#FAF8F5] px-3.5 py-1 rounded-full border border-[#D4AF37]/30 shadow-xs">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Our Legacy & Heritage</span>
            </div>

            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1A1613] leading-tight">
              The Story of Panache Sunita Boutique
            </h2>

            <p className="text-sm sm:text-base text-[#5A5047] leading-relaxed">
              Nestled near Katora Talab in Civil Lines, Raipur, <strong className="text-[#1A1613]">Panache Sunita Boutique</strong> was born out of a deep passion for preserving Indian heritage handwork while sculpting contemporary silhouettes.
            </p>

            <p className="text-xs sm:text-sm text-[#6A5E54] leading-relaxed">
              Under the creative direction of founder <strong>Sunita ji</strong>, our boutique brings together legacy Zardozi karigars, master pattern makers, and personal stylists. We believe that true luxury lies in individual fit — creating outfits that fit not just your measurements, but your personality and heritage celebration.
            </p>

            {/* Core Values Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {[
                'Bespoke Tailoring & Multi-Trial Fittings',
                'Legacy Zardozi & Gota Patti Artisans',
                'Handpicked Pure Silks & Organzas',
                'Personalized Designer Consultation',
                'Friendly & Patient Boutique Staff',
                'Promised Event Timeline Delivery'
              ].map((val, idx) => (
                <div key={idx} className="flex items-center space-x-2 text-xs font-medium text-[#2C2723]">
                  <div className="w-4 h-4 rounded-full bg-[#DFBA67]/20 text-[#9A7712] flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{val}</span>
                </div>
              ))}
            </div>

            {/* Founder Quote Card */}
            <div className="p-4 rounded-2xl bg-white border border-[#D4AF37]/30 shadow-xs flex items-center space-x-4">
              <div className="w-12 h-12 rounded-full bg-gold-gradient text-white flex items-center justify-center font-serif-luxury text-xl font-bold flex-shrink-0">
                S
              </div>
              <div>
                <p className="text-xs italic text-[#4A423A]">
                  "Every stitch should tell a story of grace, confidence, and royal elegance."
                </p>
                <span className="text-[11px] font-bold text-[#1A1613] block mt-0.5">
                  — Sunita ji, Founder & Head Designer
                </span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
