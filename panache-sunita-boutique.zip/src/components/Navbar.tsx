import React, { useState, useEffect } from 'react';
import { 
  Phone, 
  MapPin, 
  Heart, 
  Search, 
  Menu, 
  X, 
  MessageCircle, 
  Sparkles,
  Scissors
} from 'lucide-react';
import { BOUTIQUE_INFO } from '../data/boutiqueData';

interface NavbarProps {
  wishlistCount: number;
  onOpenWishlist: () => void;
  onOpenCustomDesign: () => void;
  onOpenMeasurementGuide: () => void;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  wishlistCount,
  onOpenWishlist,
  onOpenCustomDesign,
  onOpenMeasurementGuide,
  activeSection,
  onNavigate,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', id: 'hero' },
    { name: 'Categories', id: 'categories' },
    { name: 'Collections', id: 'collections' },
    { name: 'Custom Tailoring', id: 'custom-design' },
    { name: 'About Us', id: 'about' },
    { name: 'Gallery', id: 'gallery' },
    { name: 'Reviews', id: 'reviews' },
    { name: 'Contact', id: 'contact' },
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  const whatsappMessage = encodeURIComponent(
    `Hi Panache Sunita Boutique! I would like to inquire about custom outfits and book a consultation.`
  );

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
      {/* Top Announcement Bar */}
      <div className="bg-[#1A1613] text-[#FAF8F5] text-xs py-2 px-4 border-b border-[#D4AF37]/20">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center space-x-4">
            <span className="flex items-center space-x-1 text-[#DFBA67]">
              <Sparkles className="w-3.5 h-3.5" />
              <span className="font-medium">Bespoke Designer Tailoring in Raipur</span>
            </span>
            <span className="hidden md:inline text-[#D4AF37]/40">|</span>
            <span className="hidden md:flex items-center space-x-1 text-xs text-[#E5D7C4]">
              <MapPin className="w-3 h-3 text-[#DFBA67]" />
              <span>Civil Lines, Katora Talab, Raipur</span>
            </span>
          </div>

          <div className="flex items-center space-x-4 text-xs">
            <a 
              href={`https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}?text=${whatsappMessage}`}
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-1 text-[#25D366] hover:underline font-medium"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-current" />
              <span>WhatsApp Us</span>
            </a>
            <span className="text-[#D4AF37]/40">|</span>
            <a 
              href={`tel:${BOUTIQUE_INFO.phone}`}
              className="flex items-center space-x-1 hover:text-[#DFBA67] transition-colors"
            >
              <Phone className="w-3 h-3 text-[#DFBA67]" />
              <span>{BOUTIQUE_INFO.phone}</span>
            </a>
            <span className="text-[#D4AF37]/40">|</span>
            <div className="flex items-center space-x-1 text-[#DFBA67]">
              <span>★ {BOUTIQUE_INFO.rating}</span>
              <span className="text-gray-400">({BOUTIQUE_INFO.totalReviews}+ Reviews)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <nav 
        className={`transition-all duration-300 ${
          isScrolled 
            ? 'bg-[#FAF8F5]/95 backdrop-blur-md shadow-md py-3 border-b border-[#D4AF37]/20' 
            : 'bg-[#FAF8F5]/80 backdrop-blur-sm py-4 border-b border-[#D4AF37]/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Logo & Brand Name */}
          <div 
            className="flex items-center space-x-3 cursor-pointer group"
            onClick={() => handleLinkClick('hero')}
          >
            <div className="w-10 h-10 rounded-full bg-gold-gradient p-[1.5px] shadow-sm flex items-center justify-center">
              <div className="w-full h-full bg-[#FAF8F5] rounded-full flex items-center justify-center group-hover:bg-[#1A1613] transition-colors">
                <span className="font-serif-luxury font-bold text-lg text-[#9A7712] group-hover:text-[#DFBA67] transition-colors">P</span>
              </div>
            </div>
            <div>
              <span className="font-serif-luxury text-xl sm:text-2xl font-bold tracking-tight text-[#1A1613] block leading-none">
                Panache Sunita
              </span>
              <span className="text-[10px] tracking-widest uppercase font-medium text-[#9A7712] block mt-0.5">
                Boutique • Raipur
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden lg:flex items-center space-x-7">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`text-xs uppercase tracking-wider font-semibold transition-all relative py-1 ${
                  activeSection === link.id
                    ? 'text-[#9A7712]'
                    : 'text-[#4A423A] hover:text-[#9A7712]'
                }`}
              >
                {link.name}
                {activeSection === link.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-gold-gradient rounded-full" />
                )}
              </button>
            ))}
          </div>

          {/* Action CTAs & Drawer Triggers */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            {/* Self Measurement Guide Button */}
            <button
              onClick={onOpenMeasurementGuide}
              className="hidden sm:flex items-center space-x-1.5 text-xs text-[#2C2723] bg-[#F4ECE1] hover:bg-[#DFBA67]/20 border border-[#D4AF37]/40 px-3 py-1.5 rounded-full transition-colors font-medium"
              title="View Measurement Guide"
            >
              <Scissors className="w-3.5 h-3.5 text-[#9A7712]" />
              <span>Size Guide</span>
            </button>

            {/* Wishlist Button */}
            <button
              onClick={onOpenWishlist}
              className="relative p-2 text-[#2C2723] hover:text-[#9A7712] transition-colors rounded-full hover:bg-[#F4ECE1]"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#9A7712] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Custom Order CTA */}
            <button
              onClick={onOpenCustomDesign}
              className="hidden sm:flex items-center space-x-1.5 bg-gold-gradient text-white text-xs font-semibold px-4 py-2 rounded-full shadow-sm hover:shadow-md hover:brightness-105 transition-all uppercase tracking-wider"
            >
              <Sparkles className="w-3.5 h-3.5 text-white" />
              <span>Custom Outfit</span>
            </button>

            {/* Mobile Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#1A1613] hover:text-[#9A7712] focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FAF8F5] border-b border-[#D4AF37]/20 px-4 pt-3 pb-6 shadow-lg space-y-3">
            <div className="grid grid-cols-2 gap-2 pb-3 border-b border-[#D4AF37]/10">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`text-left text-xs uppercase tracking-wider font-semibold py-2 px-3 rounded-lg transition-colors ${
                    activeSection === link.id
                      ? 'bg-[#F4ECE1] text-[#9A7712]'
                      : 'text-[#4A423A] hover:bg-[#F4ECE1]/60'
                  }`}
                >
                  {link.name}
                </button>
              ))}
            </div>

            <div className="flex flex-col space-y-2 pt-1">
              <button
                onClick={() => {
                  onOpenCustomDesign();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center space-x-2 bg-gold-gradient text-white text-xs font-semibold py-2.5 rounded-full shadow-sm"
              >
                <Sparkles className="w-4 h-4" />
                <span>Book Custom Design & Fitting</span>
              </button>

              <button
                onClick={() => {
                  onOpenMeasurementGuide();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center space-x-2 bg-[#F4ECE1] text-[#1A1613] border border-[#D4AF37]/30 text-xs font-medium py-2 rounded-full"
              >
                <Scissors className="w-3.5 h-3.5 text-[#9A7712]" />
                <span>Interactive Size & Measurement Guide</span>
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
