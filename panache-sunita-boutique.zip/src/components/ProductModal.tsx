import React, { useState } from 'react';
import { OutfitProduct } from '../types';
import { BOUTIQUE_INFO } from '../data/boutiqueData';
import { X, Star, MessageCircle, Scissors, Check, Heart, ShieldCheck } from 'lucide-react';

interface ProductModalProps {
  product: OutfitProduct | null;
  onClose: () => void;
  onOpenCustomDesign: () => void;
  onOpenMeasurementGuide: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (productId: string) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onOpenCustomDesign,
  onOpenMeasurementGuide,
  isWishlisted,
  onToggleWishlist,
}) => {
  if (!product) return null;

  const [selectedImage, setSelectedImage] = useState<string>(product.image);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'Custom Tailored');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0] || '');

  const allImages = [product.image, ...(product.additionalImages || [])];

  const getWhatsappUrl = () => {
    const text = encodeURIComponent(
      `Hi Panache Sunita Boutique! I'm inquiring about "${product.name}"\n` +
      `• Price: ₹${product.price.toLocaleString('en-IN')}\n` +
      `• Selected Size: ${selectedSize}\n` +
      `• Selected Color: ${selectedColor || 'Default'}\n` +
      `Could you please share custom stitching timeline and fabric samples?`
    );
    return `https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}?text=${text}`;
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-3xl max-w-4xl w-full border border-[#D4AF37]/30 shadow-2xl overflow-hidden my-auto relative flex flex-col md:flex-row max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2.5 bg-white/90 text-stone-700 hover:text-black hover:bg-white rounded-full transition-colors shadow-md"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Product Image Gallery */}
        <div className="md:w-1/2 p-6 bg-stone-50 flex flex-col justify-between space-y-4">
          <div className="relative h-80 sm:h-96 w-full rounded-2xl overflow-hidden border border-stone-200 shadow-sm bg-white">
            <img
              src={selectedImage}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-top"
            />
            {product.isBestSeller && (
              <span className="absolute top-3 left-3 bg-gold-gradient text-white text-[10px] font-bold px-2.5 py-1 rounded uppercase tracking-widest shadow-xs">
                Best Seller
              </span>
            )}
          </div>

          {/* Thumbnails list */}
          {allImages.length > 1 && (
            <div className="flex items-center space-x-2 overflow-x-auto pb-1">
              {allImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(img)}
                  className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-all flex-shrink-0 ${
                    selectedImage === img ? 'border-[#9A7712] scale-105' : 'border-stone-200 opacity-70'
                  }`}
                >
                  <img
                    src={img}
                    alt="Thumbnail"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Details & Custom Options */}
        <div className="md:w-1/2 p-6 sm:p-8 flex flex-col justify-between space-y-6 overflow-y-auto max-h-[85vh]">
          
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-[#9A7712] mb-1">
                <span className="uppercase tracking-widest">{product.categoryName}</span>
                <div className="flex items-center space-x-1 text-amber-500 font-bold">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span>{product.rating} ({product.reviewsCount} Reviews)</span>
                </div>
              </div>

              <h2 className="font-serif-luxury text-2xl font-bold text-[#1A1613]">
                {product.name}
              </h2>

              <div className="mt-2 flex items-baseline space-x-3">
                <span className="text-2xl font-bold text-[#1A1613]">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
                {product.originalPrice && (
                  <span className="text-sm text-stone-400 line-through">
                    ₹{product.originalPrice.toLocaleString('en-IN')}
                  </span>
                )}
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                  Custom Stitching Included
                </span>
              </div>
            </div>

            <p className="text-xs text-[#5A5047] leading-relaxed">
              {product.description}
            </p>

            {/* Spec Highlights */}
            <div className="p-4 bg-[#FAF8F5] rounded-2xl border border-[#D4AF37]/20 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-stone-500">Fabric Composition:</span>
                <span className="font-bold text-[#1A1613]">{product.fabric}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Artisan Work:</span>
                <span className="font-bold text-[#9A7712]">{product.workType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Fitting Guarantee:</span>
                <span className="font-bold text-emerald-600">100% Bespoke Trial Included</span>
              </div>
            </div>

            {/* Color Options */}
            {product.colors && product.colors.length > 0 && (
              <div>
                <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-2">
                  Available Color Options
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.colors.map((c) => (
                    <button
                      key={c}
                      onClick={() => setSelectedColor(c)}
                      className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                        selectedColor === c
                          ? 'bg-[#1A1613] text-[#DFBA67] font-semibold'
                          : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Options & Guide Trigger */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider">
                  Select Size or Measurement
                </label>
                <button
                  onClick={onOpenMeasurementGuide}
                  className="text-xs text-[#9A7712] font-semibold hover:underline flex items-center space-x-1"
                >
                  <Scissors className="w-3 h-3" />
                  <span>View Size Guide</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      selectedSize === s
                        ? 'bg-gold-gradient text-white shadow-xs'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200 border border-stone-200'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Action CTAs */}
          <div className="space-y-3 pt-4 border-t border-stone-200">
            <a
              href={getWhatsappUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center space-x-2 bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold text-xs py-3.5 px-4 rounded-xl shadow-md transition-colors uppercase tracking-wider"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>Inquire & Order via WhatsApp</span>
            </a>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onClose();
                  onOpenCustomDesign();
                }}
                className="w-full flex items-center justify-center space-x-1.5 bg-[#F4ECE1] text-[#1A1613] hover:bg-[#DFBA67]/20 border border-[#D4AF37]/40 text-xs font-semibold py-2.5 rounded-xl transition-colors"
              >
                <Scissors className="w-3.5 h-3.5 text-[#9A7712]" />
                <span>Custom Alteration</span>
              </button>

              <button
                onClick={() => onToggleWishlist(product.id)}
                className={`w-full flex items-center justify-center space-x-1.5 text-xs font-semibold py-2.5 rounded-xl border transition-colors ${
                  isWishlisted
                    ? 'bg-rose-50 border-rose-200 text-rose-600'
                    : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-current' : ''}`} />
                <span>{isWishlisted ? 'Saved' : 'Save Outfit'}</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
