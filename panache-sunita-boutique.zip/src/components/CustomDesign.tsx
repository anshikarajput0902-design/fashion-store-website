import React, { useState } from 'react';
import { 
  Scissors, 
  Sparkles, 
  CheckCircle2, 
  MessageCircle, 
  Ruler, 
  Calendar, 
  MapPin, 
  User, 
  Phone, 
  ArrowRight, 
  ArrowLeft,
  Upload,
  Info
} from 'lucide-react';
import { FABRIC_OPTIONS, EMBROIDERY_OPTIONS, BOUTIQUE_INFO } from '../data/boutiqueData';
import customHandworkImg from '../assets/images/custom_handwork_1785919768516.jpg';

interface CustomDesignProps {
  onOpenMeasurementGuide: () => void;
}

export const CustomDesign: React.FC<CustomDesignProps> = ({ onOpenMeasurementGuide }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);

  // Form State
  const [outfitType, setOutfitType] = useState('Bridal Lehenga');
  const [selectedFabrics, setSelectedFabrics] = useState<string[]>(['Pure Raw Silk']);
  const [selectedEmbroidery, setSelectedEmbroidery] = useState<string[]>(['Royal Zardozi']);
  const [colorPreference, setColorPreference] = useState('Crimson Red & Antique Gold');
  const [budgetRange, setBudgetRange] = useState('₹40,000 - ₹75,000');
  const [eventDate, setEventDate] = useState('');
  
  // Client Info
  const [clientName, setClientName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('Raipur');
  const [notes, setNotes] = useState('');

  // Measurement Option
  const [measurementOption, setMeasurementOption] = useState<'self' | 'boutique-visit' | 'home-visit-raipur'>('boutique-visit');
  const [measurements, setMeasurements] = useState({
    bust: '',
    waist: '',
    hips: '',
    blouseLength: '',
    shoulderWidth: '',
    lehengaLength: '',
  });

  const outfitTypes = [
    { name: 'Bridal Lehenga', desc: 'Heavy royal lehengas with dual dupattas' },
    { name: 'Sangeet / Reception Lehenga', desc: 'Sparkling mirror & sequin lehengas' },
    { name: 'Designer Indo-Western Gown', desc: 'Floor-touching evening couture' },
    { name: 'Saree & Custom Blouse', desc: 'Bespoke padded & neck-detailed blouses' },
    { name: 'Flared Anarkali / Sharara', desc: 'Layered festive suit sets' },
    { name: 'Indo-Western Crop & Dhoti', desc: 'Modern fusion jacket ensembles' },
  ];

  const handleFabricToggle = (fabric: string) => {
    setSelectedFabrics((prev) =>
      prev.includes(fabric) ? prev.filter((f) => f !== fabric) : [...prev, fabric]
    );
  };

  const handleEmbroideryToggle = (emb: string) => {
    setSelectedEmbroidery((prev) =>
      prev.includes(emb) ? prev.filter((e) => e !== emb) : [...prev, emb]
    );
  };

  const handleWhatsAppSubmit = () => {
    const text = encodeURIComponent(
      `Hi Panache Sunita Boutique! I would like to order a custom outfit:\n\n` +
      `📌 *Outfit Type:* ${outfitType}\n` +
      `🧵 *Fabrics:* ${selectedFabrics.join(', ')}\n` +
      `✨ *Handwork:* ${selectedEmbroidery.join(', ')}\n` +
      `🎨 *Color:* ${colorPreference}\n` +
      `💰 *Budget Range:* ${budgetRange}\n` +
      `📅 *Target Date:* ${eventDate || 'Flexible'}\n` +
      `📏 *Measurement Mode:* ${measurementOption.toUpperCase()}\n` +
      `👤 *Name:* ${clientName || 'Valued Client'}\n` +
      `📞 *Phone:* ${phone}\n` +
      `📍 *City:* ${city}\n` +
      (notes ? `📝 *Notes:* ${notes}` : '')
    );

    window.open(`https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}?text=${text}`, '_blank');
    setSubmitted(true);
  };

  return (
    <section id="custom-design" className="py-20 bg-[#FAF8F5] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#F4ECE1] px-3.5 py-1 rounded-full border border-[#D4AF37]/30">
            <Scissors className="w-3.5 h-3.5" />
            <span>Bespoke Customization Atelier</span>
          </div>

          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1A1613]">
            Design Your Custom Outfit
          </h2>

          <p className="text-sm sm:text-base text-[#6A5E54]">
            Have a specific design in mind or want a matching outfit customized to your exact measurements? Walk through our simple 5-step custom tailoring builder.
          </p>
        </div>

        {/* 4-Pillar Process Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          {[
            { step: '01', title: 'Consultation & Concept', desc: 'Share your vision, color palettes, or reference photos with designer Sunita ji.' },
            { step: '02', title: 'Fabric & Artisan Work', desc: 'Handpick pure silks, organza, and custom Zardozi or Gota Patti handwork embroidery.' },
            { step: '03', title: 'Bespoke Measurement', desc: 'Visit our Raipur boutique, request home measurement, or submit your measurements.' },
            { step: '04', title: 'Trial & Perfect Fitting', desc: 'Enjoy trial check-ins with master tailors ensuring 100% flawless silhouette comfort.' }
          ].map((proc, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-6 border border-[#D4AF37]/20 shadow-xs relative space-y-2">
              <span className="font-serif-luxury text-3xl font-bold text-gold-metallic block">
                {proc.step}
              </span>
              <h4 className="font-serif-luxury text-base font-bold text-[#1A1613]">
                {proc.title}
              </h4>
              <p className="text-xs text-[#6A5E54] leading-relaxed">
                {proc.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Interactive Custom Order Form Container */}
        <div className="bg-white rounded-3xl border border-[#D4AF37]/30 shadow-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          
          {/* Left Visual Sidebar */}
          <div className="lg:col-span-4 bg-[#1A1613] text-[#FAF8F5] p-8 lg:p-10 flex flex-col justify-between relative overflow-hidden">
            <div className="space-y-6 relative z-10">
              <div className="inline-flex items-center space-x-2 text-[#DFBA67] text-xs font-semibold uppercase tracking-wider">
                <Sparkles className="w-4 h-4" />
                <span>Panache Craftsmanship</span>
              </div>

              <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-white leading-tight">
                Crafted for Your Special Day
              </h3>

              <p className="text-xs text-[#E5D7C4] leading-relaxed">
                Our legacy craftsmen in Raipur specialize in heavy bridal zardozi, delicate threadwork, mirror embroidery, and modern sculpted cuts.
              </p>

              {/* Artisan Image Thumbnail */}
              <div className="rounded-2xl overflow-hidden border border-[#D4AF37]/30 h-44 shadow-lg">
                <img
                  src={customHandworkImg}
                  alt="Zardozi Handwork Craft"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Size Guide Trigger Pill */}
              <button
                type="button"
                onClick={onOpenMeasurementGuide}
                className="w-full flex items-center justify-center space-x-2 bg-[#2C2723] hover:bg-[#38322D] border border-[#D4AF37]/40 text-[#DFBA67] text-xs font-semibold py-3 px-4 rounded-xl transition-colors"
              >
                <Ruler className="w-4 h-4" />
                <span>Open Measurement Guide</span>
              </button>
            </div>

            <div className="pt-6 border-t border-[#D4AF37]/20 relative z-10 text-xs text-[#DFBA67]">
              <span>📍 Store Location: Katora Talab, Civil Lines, Raipur</span>
            </div>
          </div>

          {/* Right Step-by-Step Interactive Form */}
          <div className="lg:col-span-8 p-6 sm:p-10 flex flex-col justify-between bg-white">
            
            {/* Step Progress Bar */}
            <div className="mb-8">
              <div className="flex items-center justify-between text-xs font-semibold text-[#9A7712] mb-2">
                <span>STEP {currentStep} OF 4</span>
                <span>
                  {currentStep === 1 && 'Outfit Type'}
                  {currentStep === 2 && 'Fabrics & Handwork'}
                  {currentStep === 3 && 'Color & Budget'}
                  {currentStep === 4 && 'Measurements & Details'}
                </span>
              </div>
              <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gold-gradient transition-all duration-300" 
                  style={{ width: `${(currentStep / 4) * 100}%` }}
                />
              </div>
            </div>

            {submitted ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="font-serif-luxury text-2xl font-bold text-[#1A1613]">
                  Custom Request Received!
                </h3>
                <p className="text-xs text-[#6A5E54] max-w-md mx-auto leading-relaxed">
                  Thank you, <strong>{clientName || 'Valued Client'}</strong>! We have opened WhatsApp with your custom outfit summary. Designer Sunita ji will contact you shortly to confirm fabric samples and trial timings.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setCurrentStep(1);
                  }}
                  className="inline-flex items-center space-x-2 bg-gold-gradient text-white text-xs font-semibold px-6 py-3 rounded-full shadow-sm"
                >
                  <span>Submit Another Design</span>
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                
                {/* STEP 1: Outfit Type */}
                {currentStep === 1 && (
                  <div className="space-y-4">
                    <h4 className="font-serif-luxury text-lg font-bold text-[#1A1613]">
                      What type of outfit would you like to customize?
                    </h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {outfitTypes.map((type) => (
                        <div
                          key={type.name}
                          onClick={() => setOutfitType(type.name)}
                          className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                            outfitType === type.name
                              ? 'border-[#9A7712] bg-[#F4ECE1]/60 shadow-xs'
                              : 'border-stone-200 hover:border-[#D4AF37]/50 bg-stone-50/50'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-xs text-[#1A1613]">{type.name}</span>
                            {outfitType === type.name && (
                              <CheckCircle2 className="w-4 h-4 text-[#9A7712]" />
                            )}
                          </div>
                          <span className="text-[11px] text-[#6A5E54] mt-1">{type.desc}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* STEP 2: Fabric & Handwork */}
                {currentStep === 2 && (
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-serif-luxury text-base font-bold text-[#1A1613] mb-2">
                        Select Preferred Fabrics (Multiple Choice)
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {FABRIC_OPTIONS.map((fab) => {
                          const isSelected = selectedFabrics.includes(fab);
                          return (
                            <button
                              key={fab}
                              type="button"
                              onClick={() => handleFabricToggle(fab)}
                              className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${
                                isSelected
                                  ? 'bg-[#1A1613] text-[#DFBA67] font-semibold shadow-xs'
                                  : 'bg-stone-100 text-[#4A423A] hover:bg-stone-200 border border-stone-200'
                              }`}
                            >
                              {isSelected ? `✓ ${fab}` : fab}
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-serif-luxury text-base font-bold text-[#1A1613] mb-2">
                        Handwork & Embroidery Preference
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {EMBROIDERY_OPTIONS.map((emb) => {
                          const isSelected = selectedEmbroidery.includes(emb);
                          return (
                            <button
                              key={emb}
                              type="button"
                              onClick={() => handleEmbroideryToggle(emb)}
                              className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${
                                isSelected
                                  ? 'bg-gold-gradient text-white font-semibold shadow-xs'
                                  : 'bg-stone-100 text-[#4A423A] hover:bg-stone-200 border border-stone-200'
                              }`}
                            >
                              {isSelected ? `✓ ${emb}` : emb}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}

                {/* STEP 3: Color Tone & Budget Range */}
                {currentStep === 3 && (
                  <div className="space-y-6">
                    <div>
                      <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-2">
                        Preferred Color Palette / Combination
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Royal Crimson Red & Gold, Pastel Peach, Emerald Green..."
                        value={colorPreference}
                        onChange={(e) => setColorPreference(e.target.value)}
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-xs text-[#1A1613] focus:outline-none focus:border-[#9A7712]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-2">
                        Estimated Budget Range
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {[
                          'Under ₹20,000',
                          '₹20,000 - ₹40,000',
                          '₹40,000 - ₹75,000',
                          '₹75,000+'
                        ].map((b) => (
                          <button
                            key={b}
                            type="button"
                            onClick={() => setBudgetRange(b)}
                            className={`p-3 rounded-xl text-xs font-semibold border text-center transition-all ${
                              budgetRange === b
                                ? 'bg-[#1A1613] text-[#DFBA67] border-[#1A1613]'
                                : 'bg-stone-50 text-stone-700 border-stone-200 hover:border-stone-400'
                            }`}
                          >
                            {b}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-2">
                        Target Event Date (Optional)
                      </label>
                      <input
                        type="date"
                        value={eventDate}
                        onChange={(e) => setEventDate(e.target.value)}
                        className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-[#1A1613] focus:outline-none focus:border-[#9A7712]"
                      />
                    </div>
                  </div>
                )}

                {/* STEP 4: Measurement Mode & Contact Info */}
                {currentStep === 4 && (
                  <div className="space-y-6">
                    <div>
                      <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-2">
                        How would you like to provide measurements?
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <button
                          type="button"
                          onClick={() => setMeasurementOption('boutique-visit')}
                          className={`p-3 rounded-xl border text-left text-xs font-medium space-y-1 ${
                            measurementOption === 'boutique-visit'
                              ? 'border-[#9A7712] bg-[#F4ECE1]'
                              : 'border-stone-200 bg-stone-50'
                          }`}
                        >
                          <div className="font-bold text-[#1A1613]">🏬 Store Visit (Raipur)</div>
                          <div className="text-[10px] text-stone-500">Trial & fit by master tailors</div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setMeasurementOption('home-visit-raipur')}
                          className={`p-3 rounded-xl border text-left text-xs font-medium space-y-1 ${
                            measurementOption === 'home-visit-raipur'
                              ? 'border-[#9A7712] bg-[#F4ECE1]'
                              : 'border-stone-200 bg-stone-50'
                          }`}
                        >
                          <div className="font-bold text-[#1A1613]">🏡 Doorstep Visit</div>
                          <div className="text-[10px] text-stone-500">Female tailors in Raipur</div>
                        </button>

                        <button
                          type="button"
                          onClick={() => setMeasurementOption('self')}
                          className={`p-3 rounded-xl border text-left text-xs font-medium space-y-1 ${
                            measurementOption === 'self'
                              ? 'border-[#9A7712] bg-[#F4ECE1]'
                              : 'border-stone-200 bg-stone-50'
                          }`}
                        >
                          <div className="font-bold text-[#1A1613]">📏 Enter Measurements</div>
                          <div className="text-[10px] text-stone-500">Input bust, waist & hips</div>
                        </button>
                      </div>
                    </div>

                    {measurementOption === 'self' && (
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 bg-stone-50 rounded-2xl border border-stone-200">
                        <div>
                          <label className="text-[10px] font-bold text-stone-600 block">Bust (inches)</label>
                          <input
                            type="text"
                            placeholder="e.g. 36"
                            value={measurements.bust}
                            onChange={(e) => setMeasurements({ ...measurements, bust: e.target.value })}
                            className="w-full px-3 py-1.5 bg-white border rounded text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-stone-600 block">Waist (inches)</label>
                          <input
                            type="text"
                            placeholder="e.g. 30"
                            value={measurements.waist}
                            onChange={(e) => setMeasurements({ ...measurements, waist: e.target.value })}
                            className="w-full px-3 py-1.5 bg-white border rounded text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-stone-600 block">Hips (inches)</label>
                          <input
                            type="text"
                            placeholder="e.g. 38"
                            value={measurements.hips}
                            onChange={(e) => setMeasurements({ ...measurements, hips: e.target.value })}
                            className="w-full px-3 py-1.5 bg-white border rounded text-xs"
                          />
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-1">
                          Your Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Priya Sharma"
                          value={clientName}
                          onChange={(e) => setClientName(e.target.value)}
                          className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-1">
                          Phone / WhatsApp Number *
                        </label>
                        <input
                          type="tel"
                          required
                          placeholder="e.g. +91 98271 23456"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-1">
                        Special Customization Notes or Reference Links
                      </label>
                      <textarea
                        rows={2}
                        placeholder="Describe neck style, sleeve length, dupatta draping, or special requests..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="w-full px-4 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs"
                      />
                    </div>
                  </div>
                )}

                {/* Step Controls Buttons */}
                <div className="pt-4 flex items-center justify-between border-t border-stone-200">
                  {currentStep > 1 ? (
                    <button
                      type="button"
                      onClick={() => setCurrentStep(currentStep - 1)}
                      className="flex items-center space-x-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 px-4 py-2 rounded-lg"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      <span>Back</span>
                    </button>
                  ) : <div />}

                  {currentStep < 4 ? (
                    <button
                      type="button"
                      onClick={() => setCurrentStep(currentStep + 1)}
                      className="flex items-center space-x-2 bg-gold-gradient text-white text-xs font-semibold px-6 py-3 rounded-full shadow-sm hover:brightness-105"
                    >
                      <span>Continue Step {currentStep + 1}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleWhatsAppSubmit}
                      className="flex items-center space-x-2 bg-[#25D366] text-white text-xs font-bold px-8 py-3.5 rounded-full shadow-md hover:bg-[#20ba5a] transition-colors uppercase tracking-wider"
                    >
                      <MessageCircle className="w-4 h-4 fill-current" />
                      <span>Send Order on WhatsApp</span>
                    </button>
                  )}
                </div>

              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
