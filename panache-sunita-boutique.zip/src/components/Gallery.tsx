import React, { useState } from 'react';
import { GALLERY_ITEMS } from '../data/boutiqueData';
import { GalleryItem } from '../types';
import { Sparkles, Maximize2, X, ChevronLeft, ChevronRight } from 'lucide-react';

export const Gallery: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('All');
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);

  const filterTabs = ['All', 'Bridal', 'Interior', 'Custom Handwork', 'Real Brides', 'Party Wear'];

  const filteredItems = GALLERY_ITEMS.filter(
    (item) => activeTab === 'All' || item.category === activeTab
  );

  const handleOpenLightbox = (index: number) => {
    setSelectedImageIndex(index);
  };

  const handlePrevLightbox = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedImageIndex !== null) {
      setSelectedImageIndex(
        selectedImageIndex === 0 ? filteredItems.length - 1 : selectedImageIndex - 1
      );
    }
  };

  const handleNextLightbox = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedImageIndex !== null) {
      setSelectedImageIndex(
        selectedImageIndex === filteredItems.length - 1 ? 0 : selectedImageIndex + 1
      );
    }
  };

  return (
    <section id="gallery" className="py-20 bg-[#FAF8F5] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-10">
          <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#F4ECE1] px-3.5 py-1 rounded-full border border-[#D4AF37]/30">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Visual Showcase</span>
          </div>

          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1A1613]">
            Boutique & Outfit Gallery
          </h2>

          <p className="text-sm text-[#6A5E54]">
            Take a visual tour inside Panache Sunita Boutique, our legacy hand embroidery, and real brides who shone on their special day.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center justify-center flex-wrap gap-2 mb-10">
          {filterTabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-2 rounded-full text-xs font-semibold transition-all ${
                activeTab === tab
                  ? 'bg-[#1A1613] text-[#DFBA67] shadow-sm'
                  : 'bg-white text-[#5A5047] hover:bg-[#F4ECE1] border border-[#D4AF37]/20'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Photo Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => handleOpenLightbox(idx)}
              className="group relative h-80 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-[#D4AF37]/20 transition-all duration-300 cursor-pointer bg-stone-100"
            >
              <img
                src={item.image}
                alt={item.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1A1613]/80 via-[#1A1613]/20 to-transparent opacity-80 group-hover:opacity-95 transition-opacity" />

              <span className="absolute top-4 left-4 bg-[#1A1613]/80 backdrop-blur-md text-[#DFBA67] text-[10px] font-bold px-3 py-1 rounded-full border border-[#D4AF37]/30">
                {item.category}
              </span>

              <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-white/80 text-[#1A1613] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Maximize2 className="w-4 h-4" />
              </div>

              <div className="absolute bottom-6 left-6 right-6 text-white space-y-1">
                <h3 className="font-serif-luxury text-xl font-bold leading-tight">
                  {item.title}
                </h3>
                <p className="text-xs text-amber-100/90 font-light line-clamp-2">
                  {item.caption}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {selectedImageIndex !== null && filteredItems[selectedImageIndex] && (
        <div 
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
          onClick={() => setSelectedImageIndex(null)}
        >
          {/* Close Button */}
          <button
            onClick={() => setSelectedImageIndex(null)}
            className="absolute top-6 right-6 p-3 text-white/80 hover:text-white bg-white/10 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Previous Button */}
          <button
            onClick={handlePrevLightbox}
            className="absolute left-4 sm:left-8 p-3 text-white/80 hover:text-white bg-white/10 rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Next Button */}
          <button
            onClick={handleNextLightbox}
            className="absolute right-4 sm:right-8 p-3 text-white/80 hover:text-white bg-white/10 rounded-full transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Main Lightbox Content */}
          <div 
            className="max-w-4xl max-h-[85vh] flex flex-col items-center justify-center text-center space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={filteredItems[selectedImageIndex].image}
              alt={filteredItems[selectedImageIndex].title}
              referrerPolicy="no-referrer"
              className="max-h-[70vh] w-auto max-w-full rounded-2xl border-2 border-[#D4AF37]/40 shadow-2xl object-contain"
            />
            <div className="text-white space-y-1 max-w-xl">
              <span className="text-[#DFBA67] text-xs uppercase tracking-widest font-bold">
                {filteredItems[selectedImageIndex].category}
              </span>
              <h3 className="font-serif-luxury text-2xl font-bold">
                {filteredItems[selectedImageIndex].title}
              </h3>
              <p className="text-xs text-stone-300">
                {filteredItems[selectedImageIndex].caption}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
