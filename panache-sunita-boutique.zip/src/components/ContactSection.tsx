import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  MessageCircle, 
  Mail, 
  Clock, 
  Navigation, 
  Send, 
  CheckCircle2, 
  Sparkles,
  Calendar
} from 'lucide-react';
import { BOUTIQUE_INFO } from '../data/boutiqueData';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    date: '',
    service: 'Bridal Fitting Consultation',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct WhatsApp message
    const text = encodeURIComponent(
      `Hi Panache Sunita Boutique! I would like to book an appointment:\n\n` +
      `👤 *Name:* ${formData.name}\n` +
      `📞 *Phone:* ${formData.phone}\n` +
      `📧 *Email:* ${formData.email || 'N/A'}\n` +
      `📅 *Date:* ${formData.date}\n` +
      `✂️ *Service:* ${formData.service}\n` +
      (formData.message ? `📝 *Message:* ${formData.message}` : '')
    );

    window.open(`https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}?text=${text}`, '_blank');
    setSubmitted(true);
  };

  const mapDirectionsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent("Panache Sunita Boutique 6MM2+VW4 Katora Talab Civil Lines Raipur Chhattisgarh 492001")}`;

  return (
    <section id="contact" className="py-20 bg-[#FAF8F5] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-14">
          <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#F4ECE1] px-3.5 py-1 rounded-full border border-[#D4AF37]/30">
            <MapPin className="w-3.5 h-3.5" />
            <span>Visit Our Atelier</span>
          </div>

          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1A1613]">
            Get In Touch & Visit Us
          </h2>

          <p className="text-sm text-[#6A5E54]">
            Book a personal bridal consultation with designer Sunita ji or visit our luxury showroom in Civil Lines, Raipur.
          </p>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-14">
          
          {/* Left Column: Address & Store Hours */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Store Address Card */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/25 shadow-sm space-y-6">
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-2xl bg-[#1A1613] text-[#DFBA67] flex items-center justify-center flex-shrink-0 shadow-md">
                  <MapPin className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-serif-luxury text-lg font-bold text-[#1A1613]">
                    Showroom Address
                  </h3>
                  <p className="text-xs text-[#5A5047] leading-relaxed">
                    {BOUTIQUE_INFO.address}<br />
                    {BOUTIQUE_INFO.landmark}<br />
                    <strong className="text-[#1A1613]">{BOUTIQUE_INFO.city} — {BOUTIQUE_INFO.pincode}</strong>
                  </p>
                  <a
                    href={mapDirectionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-1 text-xs font-bold text-[#9A7712] hover:underline pt-1"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Get Google Map Directions →</span>
                  </a>
                </div>
              </div>

              <div className="pt-4 border-t border-stone-100 flex items-start space-x-4">
                <div className="w-12 h-12 rounded-2xl bg-[#F4ECE1] text-[#9A7712] flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-serif-luxury text-base font-bold text-[#1A1613]">
                    Call & WhatsApp
                  </h3>
                  <a 
                    href={`tel:${BOUTIQUE_INFO.phone}`} 
                    className="text-xs font-bold text-[#1A1613] hover:text-[#9A7712] block"
                  >
                    Phone: {BOUTIQUE_INFO.phone}
                  </a>
                  <a 
                    href={`https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[#25D366] font-semibold hover:underline flex items-center space-x-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5 fill-current" />
                    <span>Instant WhatsApp Chat</span>
                  </a>
                </div>
              </div>

              <div className="pt-4 border-t border-stone-100 flex items-start space-x-4">
                <div className="w-12 h-12 rounded-2xl bg-[#F4ECE1] text-[#9A7712] flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6" />
                </div>
                <div className="space-y-1 text-xs">
                  <h3 className="font-serif-luxury text-base font-bold text-[#1A1613]">
                    Boutique Timings
                  </h3>
                  <p className="text-[#5A5047] font-medium">{BOUTIQUE_INFO.hours.weekdays}</p>
                  <p className="text-[#5A5047] font-medium">{BOUTIQUE_INFO.hours.sunday}</p>
                </div>
              </div>

            </div>

            {/* Quick WhatsApp Action Box */}
            <div className="bg-gradient-to-r from-[#25D366] to-[#128C7E] text-white p-6 rounded-3xl shadow-md flex items-center justify-between">
              <div className="space-y-1">
                <h4 className="font-bold text-sm">Need Urgent Custom Stitching?</h4>
                <p className="text-xs text-emerald-100">Send us a message on WhatsApp for instant response.</p>
              </div>
              <a
                href={`https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('Hi Panache Sunita Boutique! I need urgent information about custom stitching.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white text-[#128C7E] font-bold text-xs px-4 py-2.5 rounded-full shadow-sm hover:bg-emerald-50 whitespace-nowrap"
              >
                Chat Now
              </a>
            </div>

          </div>

          {/* Right Column: Appointment Booking Form */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 sm:p-8 border border-[#D4AF37]/30 shadow-lg">
            
            <div className="mb-6 space-y-1">
              <span className="text-xs font-bold text-[#9A7712] uppercase tracking-wider block">
                Boutique Visit & Fitting
              </span>
              <h3 className="font-serif-luxury text-2xl font-bold text-[#1A1613]">
                Book a Personal Styling Appointment
              </h3>
              <p className="text-xs text-[#6A5E54]">
                Reserve a dedicated time slot with Sunita ji for bridal drapes, custom measurements, and fabric trials.
              </p>
            </div>

            {submitted ? (
              <div className="p-8 text-center space-y-3 bg-emerald-50 rounded-2xl border border-emerald-200">
                <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto" />
                <h4 className="font-serif-luxury text-xl font-bold text-[#1A1613]">
                  Appointment Submitted!
                </h4>
                <p className="text-xs text-stone-600 max-w-sm mx-auto">
                  Thank you, <strong>{formData.name}</strong>! We have opened your WhatsApp confirmation. We look forward to welcoming you at Panache Sunita Boutique.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-2 text-xs font-bold text-[#9A7712] underline"
                >
                  Book Another Appointment
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Meenakshi Sahu"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-[#1A1613] focus:outline-none focus:border-[#9A7712]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. +91 98271 23456"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-[#1A1613] focus:outline-none focus:border-[#9A7712]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-1">
                      Preferred Date *
                    </label>
                    <input
                      type="date"
                      required
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-[#1A1613] focus:outline-none focus:border-[#9A7712]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-1">
                      Consultation Type
                    </label>
                    <select
                      value={formData.service}
                      onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                      className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-[#1A1613] focus:outline-none focus:border-[#9A7712]"
                    >
                      <option value="Bridal Fitting Consultation">Bridal Fitting Consultation</option>
                      <option value="Sangeet / Reception Outfit">Sangeet / Reception Outfit</option>
                      <option value="Custom Saree Blouse Stitching">Custom Saree Blouse Stitching</option>
                      <option value="Party Wear Gown Consultation">Party Wear Gown Consultation</option>
                      <option value="Matching Sister / Family Outfits">Matching Sister / Family Outfits</option>
                      <option value="General Boutique Visit">General Boutique Visit</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#1A1613] uppercase tracking-wider mb-1">
                    Your Requirements / Message
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Tell us about your outfit preference, color themes, or event timing..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-[#1A1613] focus:outline-none focus:border-[#9A7712]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center space-x-2 bg-gold-gradient text-white text-xs font-bold py-3.5 rounded-xl shadow-md hover:brightness-105 transition-all uppercase tracking-wider"
                >
                  <Send className="w-4 h-4" />
                  <span>Confirm Appointment via WhatsApp</span>
                </button>

              </form>
            )}

          </div>

        </div>

        {/* Interactive Google Maps Frame Component */}
        <div className="rounded-3xl overflow-hidden border-2 border-[#D4AF37]/30 shadow-xl bg-stone-100 relative h-96">
          <iframe
            title="Panache Sunita Boutique Map Location Raipur"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14878.026367332214!2d81.6500!3d21.2380!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a28dda565733fcd%3A0xb5bfa8162d0aa5c0!2sKatora%20Talab%2C%20Civil%20Lines%2C%20Raipur%2C%20Chhattisgarh%20492001!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen={false}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="w-full h-full grayscale-[20%] hover:grayscale-0 transition-all duration-500"
          />

          {/* Map Floating Card Badge */}
          <div className="absolute bottom-6 left-6 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-[#D4AF37]/30 max-w-sm hidden sm:block">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-gold-gradient text-white flex items-center justify-center font-bold">
                P
              </div>
              <div className="text-xs">
                <span className="font-bold text-[#1A1613] block">Panache Sunita Boutique</span>
                <span className="text-[#6A5E54] block">Katora Talab, Civil Lines, Raipur (492001)</span>
                <span className="text-amber-600 font-bold block mt-0.5">★ 4.4 (151 Reviews)</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
