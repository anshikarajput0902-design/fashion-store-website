import React, { useState, useMemo } from 'react';
import { FEATURED_PRODUCTS, CATEGORIES, BOUTIQUE_INFO } from '../data/boutiqueData';
import { OutfitProduct, CategoryId } from '../types';
import { 
  Heart, 
  Eye, 
  MessageCircle, 
  Star, 
  Sparkles, 
  Search, 
  Filter, 
  Check, 
  SlidersHorizontal 
} from 'lucide-react';

interface FeaturedCollectionProps {
  onQuickView: (product: OutfitProduct) => void;
  onOpenCustomDesign: () => void;
  wishlistIds: string[];
  onToggleWishlist: (productId: string) => void;
  selectedCategoryFilter?: CategoryId | 'all';
}

export const FeaturedCollection: React.FC<FeaturedCollectionProps> = ({
  onQuickView,
  onOpenCustomDesign,
  wishlistIds,
  onToggleWishlist,
  selectedCategoryFilter = 'all',
}) => {
  const [activeCategory, setActiveCategory] = useState<string>(selectedCategoryFilter);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating'>('featured');
  const [showOnlyInStock, setShowOnlyInStock] = useState(false);

  // Sync prop category filter if updated externally
  React.useEffect(() => {
    if (selectedCategoryFilter) {
      setActiveCategory(selectedCategoryFilter);
    }
  }, [selectedCategoryFilter]);

  const filteredProducts = useMemo(() => {
    return FEATURED_PRODUCTS.filter((product) => {
      const matchesCategory = activeCategory === 'all' || product.categoryId === activeCategory;
      const matchesSearch = 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.fabric.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.workType.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStock = !showOnlyInStock || product.inStock;

      return matchesCategory && matchesSearch && matchesStock;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default
    });
  }, [activeCategory, searchQuery, sortBy, showOnlyInStock]);

  const getWhatsappUrl = (product: OutfitProduct) => {
    const text = encodeURIComponent(
      `Hi Panache Sunita Boutique! I'm interested in "${product.name}" (Price: ₹${product.price.toLocaleString('en-IN')}). Could you please share customization details and stitch timeline?`
    );
    return `https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}?text=${text}`;
  };

  return (
    <section id="collections" className="py-20 bg-[#FAF8F5] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="inline-flex items-center space-x-1.5 text-xs font-semibold uppercase tracking-widest text-[#9A7712] bg-[#F4ECE1] px-3.5 py-1 rounded-full border border-[#D4AF37]/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Signature Lookbook</span>
            </div>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1A1613] mt-2">
              Featured Designer Collection
            </h2>
            <p className="text-sm text-[#6A5E54] mt-1 max-w-xl">
              Handpicked bridal outfits, embroidered sarees, and bespoke party gowns ready for custom measurements.
            </p>
          </div>

          <button
            onClick={onOpenCustomDesign}
            className="self-start md:self-auto flex items-center space-x-2 bg-gold-gradient text-white text-xs font-semibold px-6 py-3 rounded-full shadow-md hover:brightness-105 transition-all uppercase tracking-wider"
          >
            <Sparkles className="w-4 h-4 text-white" />
            <span>Customize Any Outfit</span>
          </button>
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm border border-[#D4AF37]/20 mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-[#9A7712] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search lehenga, saree, zardozi, velvet..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-[#FAF8F5] border border-[#D4AF37]/30 rounded-full text-xs text-[#1A1613] placeholder-gray-400 focus:outline-none focus:border-[#9A7712] transition-colors"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Sorting Dropdown & In-Stock Switch */}
            <div className="flex flex-wrap items-center gap-4 w-full md:w-auto justify-between md:justify-end">
              <div className="flex items-center space-x-2 text-xs">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#9A7712]" />
                <span className="text-[#6A5E54] font-medium hidden sm:inline">Sort:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-[#FAF8F5] border border-[#D4AF37]/30 rounded-lg px-3 py-2 text-xs font-medium text-[#1A1613] focus:outline-none cursor-pointer"
                >
                  <option value="featured">Featured Outfits</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Highest Rated</option>
                </select>
              </div>

              <label className="flex items-center space-x-2 text-xs text-[#5A5047] cursor-pointer">
                <input
                  type="checkbox"
                  checked={showOnlyInStock}
                  onChange={(e) => setShowOnlyInStock(e.target.checked)}
                  className="rounded border-[#D4AF37]/50 text-[#9A7712] focus:ring-[#9A7712]"
                />
                <span>In-Stock Only</span>
              </label>
            </div>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none border-t border-stone-100 pt-3">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                activeCategory === 'all'
                  ? 'bg-[#1A1613] text-[#DFBA67] shadow-sm'
                  : 'bg-[#FAF8F5] text-[#5A5047] hover:bg-[#F4ECE1] border border-[#D4AF37]/20'
              }`}
            >
              All Outfits ({FEATURED_PRODUCTS.length})
            </button>

            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  activeCategory === cat.id
                    ? 'bg-[#1A1613] text-[#DFBA67] shadow-sm'
                    : 'bg-[#FAF8F5] text-[#5A5047] hover:bg-[#F4ECE1] border border-[#D4AF37]/20'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-[#D4AF37]/20 max-w-md mx-auto my-8">
            <Search className="w-10 h-10 text-[#DFBA67] mx-auto mb-3" />
            <h3 className="font-serif-luxury text-xl font-bold text-[#1A1613]">No Outfits Found</h3>
            <p className="text-xs text-[#6A5E54] mt-1">
              Try modifying your search filter or request a custom outfit designed from scratch!
            </p>
            <button
              onClick={onOpenCustomDesign}
              className="mt-4 inline-flex items-center space-x-2 bg-gold-gradient text-white text-xs font-semibold px-5 py-2.5 rounded-full shadow-sm"
            >
              <span>Submit Custom Design Request</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {filteredProducts.map((product) => {
              const isWishlisted = wishlistIds.includes(product.id);

              return (
                <div
                  key={product.id}
                  className="group bg-white rounded-2xl overflow-hidden border border-[#D4AF37]/20 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
                >
                  {/* Card Image Container */}
                  <div className="relative h-72 sm:h-80 w-full overflow-hidden bg-stone-100">
                    <img
                      src={product.image}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700"
                    />

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 flex flex-col space-y-1">
                      {product.isBestSeller && (
                        <span className="bg-gold-gradient text-white text-[10px] font-bold px-2.5 py-0.5 rounded uppercase tracking-widest shadow-xs">
                          Best Seller
                        </span>
                      )}
                      {product.isNewArrival && (
                        <span className="bg-[#1A1613] text-[#DFBA67] text-[10px] font-bold px-2.5 py-0.5 rounded uppercase tracking-widest shadow-xs border border-[#D4AF37]/30">
                          New Arrival
                        </span>
                      )}
                    </div>

                    {/* Wishlist Button */}
                    <button
                      onClick={() => onToggleWishlist(product.id)}
                      className={`absolute top-3 right-3 p-2 rounded-full transition-all shadow-md ${
                        isWishlisted 
                          ? 'bg-rose-50 text-rose-600' 
                          : 'bg-white/80 backdrop-blur-md text-[#1A1613] hover:text-rose-600 hover:bg-white'
                      }`}
                      title={isWishlisted ? "Remove from Wishlist" : "Save to Wishlist"}
                    >
                      <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
                    </button>

                    {/* Hover Action Buttons */}
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <button
                        onClick={() => onQuickView(product)}
                        className="flex-1 flex items-center justify-center space-x-1.5 bg-white/95 backdrop-blur-md text-[#1A1613] hover:bg-[#1A1613] hover:text-white text-xs font-semibold py-2.5 px-3 rounded-xl shadow-md transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Details</span>
                      </button>

                      <a
                        href={getWhatsappUrl(product)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2.5 bg-[#25D366] text-white hover:bg-[#20ba5a] rounded-xl shadow-md transition-colors"
                        title="Inquire on WhatsApp"
                      >
                        <MessageCircle className="w-4 h-4 fill-current" />
                      </a>
                    </div>
                  </div>

                  {/* Card Info Details */}
                  <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-[11px] text-[#9A7712] font-semibold mb-1">
                        <span className="uppercase tracking-wider">{product.categoryName}</span>
                        <div className="flex items-center space-x-1 text-amber-500 font-bold">
                          <Star className="w-3 h-3 fill-current" />
                          <span>{product.rating}</span>
                        </div>
                      </div>

                      <h3 className="font-serif-luxury text-base font-bold text-[#1A1613] line-clamp-1 group-hover:text-[#9A7712] transition-colors">
                        {product.name}
                      </h3>

                      <p className="text-xs text-[#6A5E54] line-clamp-1 mt-0.5">
                        <strong className="text-[#1A1613]">Fabric:</strong> {product.fabric}
                      </p>
                      
                      <p className="text-[11px] text-stone-500 line-clamp-1 italic mt-0.5">
                        {product.workType}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                      <div>
                        <span className="text-xs text-stone-400 block line-through">
                          {product.originalPrice ? `₹${product.originalPrice.toLocaleString('en-IN')}` : ''}
                        </span>
                        <span className="font-bold text-base text-[#1A1613]">
                          ₹{product.price.toLocaleString('en-IN')}
                        </span>
                      </div>

                      <button
                        onClick={() => onQuickView(product)}
                        className="text-xs font-bold text-[#9A7712] hover:text-[#1A1613] underline underline-offset-4"
                      >
                        Details & Stitching →
                      </button>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
