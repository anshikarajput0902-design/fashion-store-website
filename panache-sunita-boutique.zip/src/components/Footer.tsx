import React, { useState } from 'react';
import { BOUTIQUE_INFO, CATEGORIES } from '../data/boutiqueData';
import { 
  Sparkles, 
  MapPin, 
  Phone, 
  MessageCircle, 
  Mail, 
  Instagram, 
  Facebook, 
  Heart,
  Send,
  CheckCircle2
} from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onOpenCustomDesign: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenCustomDesign }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail) {
      setSubscribed(true);
      setNewsletterEmail('');
    }
  };

  return (
    <footer className="bg-[#1A1613] text-[#FAF8F5] pt-16 pb-8 border-t border-[#D4AF37]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          
          {/* Brand Bio */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('hero')}>
              <div className="w-10 h-10 rounded-full bg-gold-gradient p-[1.5px] flex items-center justify-center">
                <div className="w-full h-full bg-[#1A1613] rounded-full flex items-center justify-center">
                  <span className="font-serif-luxury font-bold text-lg text-[#DFBA67]">P</span>
                </div>
              </div>
              <div>
                <span className="font-serif-luxury text-xl font-bold tracking-tight text-white block">
                  Panache Sunita
                </span>
                <span className="text-[10px] tracking-widest uppercase font-medium text-[#DFBA67] block">
                  Boutique • Raipur
                </span>
              </div>
            </div>

            <p className="text-xs text-[#E5D7C4] leading-relaxed max-w-sm">
              Where Elegance Meets Style. Premier designer boutique in Katora Talab, Raipur specializing in custom bridal lehengas, handloom sarees, couture gowns, and bespoke Zardozi handwork.
            </p>

            <div className="flex items-center space-x-3 text-xs text-[#DFBA67]">
              <span>Google Rating: <strong>4.4 ★</strong> ({BOUTIQUE_INFO.totalReviews}+ Reviews)</span>
            </div>

            {/* Social Icons */}
            <div className="flex items-center space-x-3 pt-2">
              <a
                href={`https://wa.me/${BOUTIQUE_INFO.whatsapp.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-[#25D366] text-white flex items-center justify-center hover:scale-110 transition-transform shadow-sm"
                title="WhatsApp"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white flex items-center justify-center hover:scale-110 transition-transform shadow-sm"
                title="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 rounded-full bg-blue-600 text-white flex items-center justify-center hover:scale-110 transition-transform shadow-sm"
                title="Facebook"
              >
                <Facebook className="w-4 h-4 fill-current" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-serif-luxury text-sm font-bold text-[#DFBA67] uppercase tracking-wider">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs text-[#E5D7C4]">
              {[
                { name: 'Home', id: 'hero' },
                { name: 'Categories', id: 'categories' },
                { name: 'Signature Lookbook', id: 'collections' },
                { name: 'Custom Tailoring', id: 'custom-design' },
                { name: 'About Us', id: 'about' },
                { name: 'Photo Gallery', id: 'gallery' },
                { name: 'Client Reviews', id: 'reviews' },
                { name: 'Visit Showroom', id: 'contact' },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className="hover:text-[#DFBA67] transition-colors"
                  >
                    {item.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif-luxury text-sm font-bold text-[#DFBA67] uppercase tracking-wider">
              Designer Categories
            </h4>
            <ul className="grid grid-cols-2 gap-2 text-xs text-[#E5D7C4]">
              {CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => onNavigate('collections')}
                    className="hover:text-[#DFBA67] transition-colors text-left"
                  >
                    • {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* VIP Lookbook Newsletter */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-serif-luxury text-sm font-bold text-[#DFBA67] uppercase tracking-wider">
              Join VIP Bridal Circle
            </h4>
            <p className="text-xs text-[#E5D7C4]">
              Subscribe to get early previews of new wedding collections, sangeet trunk shows, and custom fabric arrivals.
            </p>

            {subscribed ? (
              <div className="p-3 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Subscribed! Welcome to VIP Bridal Circle.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <input
                  type="email"
                  required
                  placeholder="Enter your email address..."
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#2C2723] border border-[#D4AF37]/30 rounded-xl text-xs text-white placeholder-stone-400 focus:outline-none focus:border-[#DFBA67]"
                />
                <button
                  type="submit"
                  className="w-full flex items-center justify-center space-x-1.5 bg-gold-gradient text-white text-xs font-bold py-2.5 rounded-xl hover:brightness-105 transition-all uppercase tracking-wider shadow-sm"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Subscribe</span>
                </button>
              </form>
            )}
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[#D4AF37]/20 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 gap-4">
          <p>
            © {new Date().getFullYear()} Panache Sunita Boutique. All Rights Reserved. Designed with elegance for Raipur, Chhattisgarh.
          </p>
          <div className="flex items-center space-x-4">
            <span className="hover:text-[#DFBA67] cursor-pointer">Privacy Policy</span>
            <span>•</span>
            <span className="hover:text-[#DFBA67] cursor-pointer">Custom Fitting Terms</span>
            <span>•</span>
            <span className="hover:text-[#DFBA67] cursor-pointer">Raipur Store Address</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
