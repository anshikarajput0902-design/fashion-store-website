import { BoutiqueContactInfo, Category, GalleryItem, OutfitProduct, Review } from '../types';

import heroFashionModelImg from '../assets/images/hero_fashion_model_1785919742555.jpg';
import boutiqueInteriorImg from '../assets/images/boutique_interior_1785919755789.jpg';
import customHandworkImg from '../assets/images/custom_handwork_1785919768516.jpg';

export const BOUTIQUE_INFO: BoutiqueContactInfo = {
  name: "Panache Sunita Boutique",
  tagline: "Where Elegance Meets Style",
  address: "6MM2+VW4, Katora Talab, Civil Lines",
  landmark: "Near Avanti Vihar / RS Shukla Road",
  city: "Raipur, Chhattisgarh",
  pincode: "492001",
  googleMapPlusCode: "6MM2+VW4",
  phone: "+91 98271 23456",
  whatsapp: "+91 98271 23456",
  email: "panachesunita.boutique@gmail.com",
  rating: 4.4,
  totalReviews: 151,
  hours: {
    weekdays: "Open Daily: 11:00 AM – 9:00 PM",
    sunday: "Sunday: 12:00 PM – 7:30 PM",
  },
};

export const CATEGORIES: Category[] = [
  {
    id: 'bridal-wear',
    name: 'Bridal Wear',
    description: 'Royal bridal lehengas with bespoke zardozi hand embroidery and pure raw silk fabrics.',
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=800&auto=format&fit=crop',
    itemCount: 42,
    highlightTag: 'Royal Bridal'
  },
  {
    id: 'lehengas',
    name: 'Designer Lehengas',
    description: 'Trending sangeet and mehendi lehengas with intricate gota patti and sequins.',
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=800&auto=format&fit=crop',
    itemCount: 56,
    highlightTag: 'Best Sellers'
  },
  {
    id: 'gowns',
    name: 'Couture Gowns',
    description: 'Floor-length Indo-Western cocktail gowns and evening cape dresses.',
    image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=800&auto=format&fit=crop',
    itemCount: 28,
    highlightTag: 'Cocktail Special'
  },
  {
    id: 'sarees',
    name: 'Handcrafted Sarees',
    description: 'Bespoke Kanjeevaram, Organza, and Georgette designer sarees with rich borders.',
    image: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=800&auto=format&fit=crop',
    itemCount: 65,
    highlightTag: 'Handloom Pure'
  },
  {
    id: 'party-wear',
    name: 'Party Wear',
    description: 'Glamorous designer suits, shararas, and layered ensembles for festive celebrations.',
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?q=80&w=800&auto=format&fit=crop',
    itemCount: 38,
    highlightTag: 'Trending'
  },
  {
    id: 'indo-western',
    name: 'Indo-Western Ensembles',
    description: 'Contemporary fusion crop tops, dhoti pants, jacket sets, and cape drapes.',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=800&auto=format&fit=crop',
    itemCount: 34,
    highlightTag: 'Modern Cut'
  },
  {
    id: 'kurtis',
    name: 'Designer Kurtis & Sets',
    description: 'Elegant hand-worked silk and chanderi kurtis with matching palazzos & dupattas.',
    image: 'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?q=80&w=800&auto=format&fit=crop',
    itemCount: 48,
    highlightTag: 'Daily Luxury'
  },
  {
    id: 'ethnic-wear',
    name: 'Ethnic Festive Ensembles',
    description: 'Traditional Anarkali flared gowns, Angrakhas, and handcrafted heritage suits.',
    image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?q=80&w=800&auto=format&fit=crop',
    itemCount: 50,
    highlightTag: 'Heritage'
  }
];

export const FEATURED_PRODUCTS: OutfitProduct[] = [
  {
    id: 'prod-1',
    name: 'Noor-e-Shaam Crimson Bridal Lehenga',
    categoryId: 'bridal-wear',
    categoryName: 'Bridal Wear',
    price: 68500,
    originalPrice: 75000,
    fabric: 'Pure Raw Silk & Net Dupatta',
    workType: 'Heavy Zardozi, Gota Patti & Dabka Embroidery',
    colors: ['Crimson Red', 'Royal Gold', 'Maroon'],
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1000&auto=format&fit=crop',
    additionalImages: [
      heroFashionModelImg,
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1000&auto=format&fit=crop'
    ],
    rating: 4.9,
    reviewsCount: 38,
    inStock: true,
    isBestSeller: true,
    isNewArrival: true,
    description: 'Handcrafted over 120 artisan hours, this bridal lehenga features royal floral zardozi motifs paired with dual net dupattas and a sculpted sweetheart blouse.',
    sizes: ['Custom Tailored', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'prod-2',
    name: 'Gulzar Champagne Mirror Work Lehenga',
    categoryId: 'lehengas',
    categoryName: 'Designer Lehengas',
    price: 42000,
    originalPrice: 48000,
    fabric: 'Organza & Soft Satin',
    workType: 'Real Hand-cut Mirror Work & Metallic Thread',
    colors: ['Champagne Gold', 'Dusty Rose', 'Soft Beige'],
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1000&auto=format&fit=crop',
    additionalImages: [
      'https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=1000&auto=format&fit=crop'
    ],
    rating: 4.8,
    reviewsCount: 29,
    inStock: true,
    isBestSeller: true,
    description: 'Lightweight champagne organza lehenga styled with sparkling mirror handwork, ideal for sangeet nights and reception celebrations.',
    sizes: ['Custom Tailored', 'S', 'M', 'L']
  },
  {
    id: 'prod-3',
    name: 'Aarya Emerald Velvet Sculpted Gown',
    categoryId: 'gowns',
    categoryName: 'Couture Gowns',
    price: 36500,
    originalPrice: 40000,
    fabric: 'Micro Velvet & Metallic Tulle',
    workType: '3D Sequin & Crystal Embellishment',
    colors: ['Emerald Green', 'Wine Red', 'Midnight Blue'],
    image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=1000&auto=format&fit=crop',
    rating: 4.7,
    reviewsCount: 19,
    inStock: true,
    isNewArrival: true,
    description: 'Floor-touching evening couture gown with structured shoulder cape and shimmering crystal detailing.',
    sizes: ['Custom Tailored', 'S', 'M', 'L']
  },
  {
    id: 'prod-4',
    name: 'Virasat Tissue Silk Designer Saree',
    categoryId: 'sarees',
    categoryName: 'Handcrafted Sarees',
    price: 24500,
    originalPrice: 28000,
    fabric: 'Handloom Tissue Silk',
    workType: 'Hand Embroidered Border & Blouse Accent',
    colors: ['Antiqued Gold', 'Rose Gold', 'Pastel Mint'],
    image: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?q=80&w=1000&auto=format&fit=crop',
    rating: 4.9,
    reviewsCount: 44,
    inStock: true,
    isBestSeller: true,
    description: 'Timeless tissue silk saree with woven metallic sheen and unstitched custom designer blouse piece.',
    sizes: ['Free Size (Includes Custom Blouse Stitching)']
  },
  {
    id: 'prod-5',
    name: 'Meher Peplum Sharara Ensembles',
    categoryId: 'party-wear',
    categoryName: 'Party Wear',
    price: 28900,
    originalPrice: 32000,
    fabric: 'Georgette & Crepe',
    workType: 'Tilla Embroidery & Pearl Handwork',
    colors: ['Powder Blue', 'Peach Pink', 'Ivory White'],
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?q=80&w=1000&auto=format&fit=crop',
    rating: 4.8,
    reviewsCount: 22,
    inStock: true,
    isNewArrival: true,
    description: 'Flared tiered sharara pants paired with a tailored short peplum top and sheer scalloped dupatta.',
    sizes: ['Custom Tailored', 'S', 'M', 'L', 'XL']
  },
  {
    id: 'prod-6',
    name: 'Riddhi Cape Crop Top & Dhoti Set',
    categoryId: 'indo-western',
    categoryName: 'Indo-Western Ensembles',
    price: 21500,
    originalPrice: 24000,
    fabric: 'Silk Chiffon & Satin Crepe',
    workType: 'Cutdana & Resham Thread Handwork',
    colors: ['Mauve Pink', 'Mustard Gold', 'Teal'],
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?q=80&w=1000&auto=format&fit=crop',
    rating: 4.6,
    reviewsCount: 17,
    inStock: true,
    description: 'Chic fusion ensemble featuring high-waisted pleated dhoti trousers, embellished corset top, and flowing cape.',
    sizes: ['Custom Tailored', 'S', 'M', 'L']
  },
  {
    id: 'prod-7',
    name: 'Kashida Chanderi Anarkali Set',
    categoryId: 'ethnic-wear',
    categoryName: 'Ethnic Festive Ensembles',
    price: 18500,
    originalPrice: 21000,
    fabric: 'Chanderi Silk & Organza Dupatta',
    workType: 'Gotawork & Heavy Yoke Embroidery',
    colors: ['Mustard Yellow', 'Deep Coral', 'Off-White'],
    image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?q=80&w=1000&auto=format&fit=crop',
    rating: 4.9,
    reviewsCount: 31,
    inStock: true,
    isBestSeller: true,
    description: 'Full-flared 24-kali Anarkali gown crafted in rich Chanderi silk with organza dupatta.',
    sizes: ['Custom Tailored', 'S', 'M', 'L', 'XL', 'XXL']
  },
  {
    id: 'prod-8',
    name: 'Nazakat Handcrafted Designer Kurti Set',
    categoryId: 'kurtis',
    categoryName: 'Designer Kurtis & Sets',
    price: 12800,
    originalPrice: 15000,
    fabric: 'Pure Mulberry Silk',
    workType: 'Hand-sewn Threadwork & Sequin Highlights',
    colors: ['Soft Ivory', 'Sage Green', 'Blush Pink'],
    image: 'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?q=80&w=1000&auto=format&fit=crop',
    rating: 4.8,
    reviewsCount: 26,
    inStock: true,
    description: 'Straight-cut silk kurti set with intricate neckline embroidery, palazzo pants, and organza dupatta.',
    sizes: ['Custom Tailored', 'S', 'M', 'L', 'XL']
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Priya Sharma',
    rating: 5,
    date: '2 weeks ago',
    source: 'Google Review',
    comment: 'Amazing experience! They understood exactly what I wanted for my wedding sangeet lehenga and delivered it beautifully. Fabric quality and fitting both were on point. If you want custom outfits with perfection in Raipur, visit Panache Sunita!',
    outfitPurchased: 'Custom Bridal Lehenga',
    verified: true
  },
  {
    id: 'rev-2',
    author: 'Ananya Verma',
    rating: 5,
    date: '1 month ago',
    source: 'Google Review',
    comment: 'Perfect fitting very unique design and designer handwork outfits 😊😊😊😊. Loved the zardozi detail on my blouse!',
    outfitPurchased: 'Designer Indo-Western Gown',
    verified: true
  },
  {
    id: 'rev-3',
    author: 'Meenakshi & Sakshi Sahu',
    rating: 5,
    date: '3 weeks ago',
    source: 'Google Review',
    comment: 'We had an exceptional experience customizing matching sister dresses for our cousin\'s reception. The team here manages to combine meticulous attention to detail with highly professional service. A special thanks to Sunita ji!',
    outfitPurchased: 'Matching Reception Outfits',
    verified: true
  },
  {
    id: 'rev-4',
    author: 'Ritu Agrawal',
    rating: 4,
    date: '2 months ago',
    source: 'Google Review',
    comment: 'The quality of the clothes, designs, and varieties are so trendy! Loved their boutique collection in Katora Talab.',
    outfitPurchased: 'Organza Designer Saree',
    verified: true
  },
  {
    id: 'rev-5',
    author: 'Deepika Jain',
    rating: 5,
    date: '3 months ago',
    source: 'Google Review',
    comment: 'They have great variety and good quality dresses and Kurtis. Super friendly staff who listen patiently to custom design requirements!',
    outfitPurchased: 'Chanderi Silk Kurti Set',
    verified: true
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Royal Bridal Elegance',
    category: 'Bridal',
    image: heroFashionModelImg,
    caption: 'Custom raw silk bridal lehenga with royal gold zardozi embroidery handcrafted for a Raipur bride.'
  },
  {
    id: 'gal-2',
    title: 'Panache Sunita Atelier Interior',
    category: 'Interior',
    image: boutiqueInteriorImg,
    caption: 'Our luxury boutique showroom located at Civil Lines, Katora Talab, Raipur.'
  },
  {
    id: 'gal-3',
    title: 'Artisan Zardozi Handwork',
    category: 'Custom Handwork',
    image: customHandworkImg,
    caption: 'Intricate golden threadwork and gota patti detail crafted by master karigars.'
  },
  {
    id: 'gal-4',
    title: 'Glistening Sangeet Lehenga',
    category: 'Bridal',
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?q=80&w=1000&auto=format&fit=crop',
    caption: 'Champagne gold mirror-work organza lehenga designed for festive sangeet evenings.'
  },
  {
    id: 'gal-5',
    title: 'Happy Panache Bride',
    category: 'Real Brides',
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?q=80&w=1000&auto=format&fit=crop',
    caption: 'Our gorgeous client Priya wearing her custom Panache Sunita bridal attire.'
  },
  {
    id: 'gal-6',
    title: 'Sculpted Cocktail Gown',
    category: 'Party Wear',
    image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=1000&auto=format&fit=crop',
    caption: 'Deep emerald micro-velvet evening gown with hand-sewn crystal accents.'
  }
];

export const WHY_CHOOSE_US = [
  {
    icon: 'Sparkles',
    title: 'Premium Handpicked Fabrics',
    description: 'Only pure Mulberry silk, Chanderi, handloom Tissue, Organza, and micro-velvet sourced directly from India\'s top weaver hubs.'
  },
  {
    icon: 'Scissors',
    title: 'Perfect Fitting Guarantee',
    description: 'Multiple trial check-ins with master tailors to guarantee flawless silhouette, drape, and posture comfort.'
  },
  {
    icon: 'Award',
    title: 'Artisan Designer Handwork',
    description: 'Bespoke Zardozi, Gota Patti, Cutdana, and Dabka embroidery lovingly sewn by legacy master craftsmen.'
  },
  {
    icon: 'HeartHandshake',
    title: 'Personalized Stylist Staff',
    description: 'Warm, patient stylist consultations led by designer Sunita ji to bring your dream outfit vision to reality.'
  },
  {
    icon: 'Clock',
    title: 'Timely Express Service',
    description: 'Promised delivery timelines for weddings, sangeet, and festive events with express stitching options.'
  }
];

export const FABRIC_OPTIONS = [
  'Pure Raw Silk',
  'Handloom Organza',
  'Micro Velvet',
  'Chanderi Silk',
  'Tissue Silk',
  'Pure Georgette',
  'Satin Crepe',
  'Net & Tulle'
];

export const EMBROIDERY_OPTIONS = [
  'Royal Zardozi',
  'Gota Patti',
  'Hand Cut Mirror Work',
  'Resham Threadwork',
  'Cutdana & Pearl',
  'Dabka Embroidery',
  'Sequins & Crystals',
  'Minimal Fabric Borders'
];
