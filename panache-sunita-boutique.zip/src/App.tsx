import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Categories } from './components/Categories';
import { FeaturedCollection } from './components/FeaturedCollection';
import { CustomDesign } from './components/CustomDesign';
import { AboutUs } from './components/AboutUs';
import { Gallery } from './components/Gallery';
import { Testimonials } from './components/Testimonials';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ContactSection } from './components/ContactSection';
import { ProductModal } from './components/ProductModal';
import { MeasurementGuideModal } from './components/MeasurementGuideModal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { Footer } from './components/Footer';

import { OutfitProduct, CategoryId } from './types';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [selectedProduct, setSelectedProduct] = useState<OutfitProduct | null>(null);
  const [isMeasurementGuideOpen, setIsMeasurementGuideOpen] = useState<boolean>(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState<boolean>(false);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<CategoryId | 'all'>('all');

  // LocalStorage Wishlist Persistence
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('panache_wishlist');
      return saved ? JSON.parse(saved) : ['prod-1', 'prod-4'];
    } catch {
      return ['prod-1', 'prod-4'];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('panache_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.error(e);
    }
  }, [wishlistIds]);

  const handleToggleWishlist = (productId: string) => {
    setWishlistIds((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectCategory = (categoryId: CategoryId) => {
    setSelectedCategoryFilter(categoryId);
    handleNavigate('collections');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#2C2723] font-sans selection:bg-[#D4AF37]/30 selection:text-[#1A1613]">
      
      {/* Sticky Luxury Navbar */}
      <Navbar
        wishlistCount={wishlistIds.length}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenCustomDesign={() => handleNavigate('custom-design')}
        onOpenMeasurementGuide={() => setIsMeasurementGuideOpen(true)}
        activeSection={activeSection}
        onNavigate={handleNavigate}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Banner Section */}
        <Hero
          onExploreCollections={() => handleNavigate('collections')}
          onBookCustomFit={() => handleNavigate('custom-design')}
        />

        {/* Categories Showcase */}
        <Categories onSelectCategory={handleSelectCategory} />

        {/* Featured Signature Collection */}
        <FeaturedCollection
          onQuickView={(product) => setSelectedProduct(product)}
          onOpenCustomDesign={() => handleNavigate('custom-design')}
          wishlistIds={wishlistIds}
          onToggleWishlist={handleToggleWishlist}
          selectedCategoryFilter={selectedCategoryFilter}
        />

        {/* Custom Outfit Builder & Bespoke Tailoring */}
        <CustomDesign
          onOpenMeasurementGuide={() => setIsMeasurementGuideOpen(true)}
        />

        {/* Why Choose Panache Sunita Boutique */}
        <WhyChooseUs />

        {/* Story & Legacy of Boutique */}
        <AboutUs />

        {/* Lookbook & Boutique Interior Gallery */}
        <Gallery />

        {/* Customer Reviews & Google Rating */}
        <Testimonials />

        {/* Contact, Map, Timings & Appointment Booking */}
        <ContactSection />
      </main>

      {/* Luxury Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenCustomDesign={() => handleNavigate('custom-design')}
      />

      {/* Product Quick View Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onOpenCustomDesign={() => handleNavigate('custom-design')}
        onOpenMeasurementGuide={() => setIsMeasurementGuideOpen(true)}
        isWishlisted={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
      />

      {/* Size & Measurement Guide Modal */}
      {isMeasurementGuideOpen && (
        <MeasurementGuideModal
          onClose={() => setIsMeasurementGuideOpen(false)}
          onOpenCustomDesign={() => handleNavigate('custom-design')}
        />
      )}

      {/* Wishlist Saved Outfits Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistIds={wishlistIds}
        onRemoveFromWishlist={handleToggleWishlist}
        onQuickView={(product) => setSelectedProduct(product)}
      />

    </div>
  );
}
